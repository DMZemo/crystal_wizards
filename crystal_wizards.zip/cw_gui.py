"""
Crystal Wizards - Enhanced Pygame GUI Implementation

Enhanced version with improved graphics, animations, particle effects, and visual polish.
Features wizard sprites, smooth movement animations, spell effects, and enhanced UI.
"""

import math
import os
import random
import sys
import pygame
from pathlib import Path
from cw_entities import AIWizard
from cw_game import CrystalWizardsGame
from ui import Button, HighlightManager, ActionPanel
from sound_manager import sound_manager
from dice_animation import DiceRollManager
from blood_magic_choice_dialog import BloodMagicChoiceDialog
from blood_magic_dialog import BloodMagicDialog
from help_menu_system import PauseMenuDialog
from particle_system import particle_system
from sprite_manager import sprite_manager
from animation_system import animation_manager
from ai_animation_config import *

def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller"""
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = Path(sys._MEIPASS)
    except AttributeError:
        # Running in development mode
        base_path = Path(__file__).parent
    
    return base_path / relative_path

# Colors
COLORS = {
    'white': (255, 255, 255),
    'black': (0, 0, 0),
    'red': (220, 50, 50),
    'blue': (50, 50, 220),
    'green': (50, 220, 50),
    'yellow': (220, 220, 50),
    'grey': (128, 128, 128),
    'light_grey': (200, 200, 200),
    'dark_grey': (64, 64, 64),
    'brown': (139, 69, 19),
    'light_blue': (173, 216, 230),
    'gold': (255, 215, 0),
    'wild': (230, 50, 230),
    'transparent': (0, 0, 0, 0)  # For transparent surfaces
}


class QuitConfirmDialog:
    def __init__(self, screen, font):
        self.screen = screen
        self.font = font
        self.visible = False
        self.result = None  # True for Yes, False for No

    def show(self):
        self.visible = True
        self.result = None

    def hide(self):
        self.visible = False

    def run_modal(self):
        """Run a simple modal loop until user selects Yes/No or cancels."""
        self.show()
        clock = pygame.time.Clock()
        while self.visible and self.result is None:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # Treat window close inside dialog as a cancel
                    self.result = False
                elif event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_ESCAPE, pygame.K_n):
                        self.result = False
                    elif event.key in (pygame.K_RETURN, pygame.K_y):
                        self.result = True
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    if self._btn_yes.collidepoint((mx, my)):
                        self.result = True
                    elif self._btn_no.collidepoint((mx, my)):
                        self.result = False

            self.draw()
            pygame.display.flip()
            clock.tick(60)

        self.hide()
        return bool(self.result)

    def draw(self):
        sw, sh = self.screen.get_size()
        # Dim background
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        self.screen.blit(overlay, (0, 0))

        # Dialog
        w, h = int(sw * 0.45), int(sh * 0.25)
        x, y = (sw - w) // 2, (sh - h) // 2
        dialog_rect = pygame.Rect(x, y, w, h)
        pygame.draw.rect(self.screen, COLORS['white'], dialog_rect, border_radius=10)
        pygame.draw.rect(self.screen, COLORS['black'], dialog_rect, 2, border_radius=10)

        # Text
        title = self.font.render("Quit Crystal Wizards?", True, COLORS['black'])
        subtitle = pygame.font.Font(None, int(h * 0.36)).render(
            "Are you sure you want to quit?", True, COLORS['dark_grey']
        )
        self.screen.blit(title, title.get_rect(center=(x + w // 2, y + int(h * 0.3))))
        self.screen.blit(subtitle, subtitle.get_rect(center=(x + w // 2, y + int(h * 0.52))))

        # Buttons
        btn_w, btn_h = int(w * 0.28), int(h * 0.26)
        gap = int(w * 0.08)
        bx1 = x + w // 2 - btn_w - gap // 2
        bx2 = x + w // 2 + gap // 2
        by = y + int(h * 0.65)
        self._btn_yes = pygame.Rect(bx1, by, btn_w, btn_h)
        self._btn_no = pygame.Rect(bx2, by, btn_w, btn_h)

        pygame.draw.rect(self.screen, COLORS['green'], self._btn_yes, border_radius=8)
        pygame.draw.rect(self.screen, COLORS['black'], self._btn_yes, 2, border_radius=8)
        pygame.draw.rect(self.screen, COLORS['red'], self._btn_no, border_radius=8)
        pygame.draw.rect(self.screen, COLORS['black'], self._btn_no, 2, border_radius=8)

        yes_text = pygame.font.Font(None, int(btn_h * 1.0)).render("Yes", True, COLORS['white'])
        no_text = pygame.font.Font(None, int(btn_h * 1.0)).render("No", True, COLORS['white'])
        self.screen.blit(yes_text, yes_text.get_rect(center=self._btn_yes.center))
        self.screen.blit(no_text, no_text.get_rect(center=self._btn_no.center))

class BlockingDialog:
    def __init__(self, screen, font, wizard, damage, caster, game=None):
        self.screen = screen
        self.font = font
        self.wizard = wizard
        self.damage = damage
        self.caster = caster
        self.game = game
        self.visible = False
        self.result = None  # Amount of damage blocked (None means still deciding)
        
        # UI state - only allow blocking 1 damage with 1 crystal
        self.crystals_to_spend = {'red': 0, 'blue': 0, 'green': 0, 'yellow': 0, 'white': 0}
        self.max_crystals = min(1, wizard.get_total_crystals_for_blocking())  # Maximum 1 crystal can be used
        self.total_selected = 0
        self.selected_crystal_color = None  # Track which single crystal is selected
        
        # Calculate dialog dimensions
        sw, sh = self.screen.get_size()
        self.dialog_w = int(sw * 0.7)
        self.dialog_h = int(sh * 0.6)
        self.dialog_x = (sw - self.dialog_w) // 2
        self.dialog_y = (sh - self.dialog_h) // 2
        
    def show(self):
        self.visible = True
        self.result = None
        
    def run_modal(self):
        """Run modal dialog until user confirms blocking choice"""
        self.show()
        clock = pygame.time.Clock()
        
        while self.visible and self.result is None:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.result = 0  # No blocking on quit
                    self.visible = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.result = 0  # No blocking on escape
                        self.visible = False
                    elif event.key == pygame.K_RETURN:
                        self._confirm_blocking()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mx, my = event.pos
                    self._handle_mouse_click(mx, my)
                        
            # Render the dialog
            self.render()
            pygame.display.flip()
            clock.tick(60)
            
        return self.result if self.result is not None else 0
    
    def _confirm_blocking(self):
        """Confirm the current blocking selection and spend crystals"""
        if self.total_selected > 0:
            # Spend the selected crystals using the new blocking logic
            crystals_spent = {}
            total_blocked = 0
            for color, amount in self.crystals_to_spend.items():
                if amount > 0:
                    available = self.wizard.crystals.get(color, 0)
                    actual_spent = min(amount, available)
                    if actual_spent > 0:
                        self.wizard.crystals[color] -= actual_spent
                        crystals_spent[color] = actual_spent
                        total_blocked += actual_spent
            
            # All blocking crystals return to board
            if self.game and crystals_spent:
                crystals_to_return = {color: amount for color, amount in crystals_spent.items() if amount > 0}
                if crystals_to_return:
                    self.game.return_crystals_to_board(crystals_to_return, self.wizard.location)
            
            self.result = total_blocked
        else:
            self.result = 0
        self.visible = False

    def _handle_mouse_click(self, mx, my):
        """Handle mouse clicks in the blocking dialog - single crystal selection only"""
        # Crystal selection (click to select/deselect a single crystal)
        colors = ['red', 'blue', 'green', 'yellow', 'white']
        crystal_section_y = self.dialog_y + 150
        
        for i, color in enumerate(colors):
            if self.wizard.crystals.get(color, 0) == 0:
                continue  # Skip colors the wizard doesn't have
                
            # Calculate crystal button area for this color (larger clickable area)
            crystal_x = self.dialog_x + 60 + i * 110
            crystal_rect = pygame.Rect(crystal_x, crystal_section_y + 10, 80, 60)
            
            if crystal_rect.collidepoint(mx, my):
                # Toggle crystal selection (only one crystal can be selected at a time)
                if self.selected_crystal_color == color:
                    # Deselect current crystal
                    self.crystals_to_spend[color] = 0
                    self.total_selected = 0
                    self.selected_crystal_color = None
                else:
                    # Clear any previously selected crystal
                    if self.selected_crystal_color:
                        self.crystals_to_spend[self.selected_crystal_color] = 0
                    
                    # Select new crystal
                    self.crystals_to_spend[color] = 1
                    self.total_selected = 1
                    self.selected_crystal_color = color
        
        # Action buttons
        button_y = self.dialog_y + self.dialog_h - 60
        
        # Block button
        block_x = self.dialog_x + self.dialog_w // 2 - 120
        block_rect = pygame.Rect(block_x, button_y, 100, 40)
        
        # Skip button  
        skip_x = self.dialog_x + self.dialog_w // 2 + 20
        skip_rect = pygame.Rect(skip_x, button_y, 100, 40)
        
        if block_rect.collidepoint(mx, my):
            self._confirm_blocking()
        elif skip_rect.collidepoint(mx, my):
            # Skip blocking
            self.result = 0
            self.visible = False
        
    def render(self):
        """Render the improved blocking dialog with clear crystal selection"""
        sw, sh = self.screen.get_size()
        
        # Semi-transparent overlay
        overlay = pygame.Surface((sw, sh), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        
        # Dialog background with rounded corners
        dialog_rect = pygame.Rect(self.dialog_x, self.dialog_y, self.dialog_w, self.dialog_h)
        pygame.draw.rect(self.screen, (45, 45, 65), dialog_rect, border_radius=15)
        pygame.draw.rect(self.screen, (255, 255, 255), dialog_rect, 3, border_radius=15)
        
        # Title section
        title_text = "⚔️ INCOMING ATTACK! ⚔️"
        title_surface = pygame.font.Font(None, 72).render(title_text, True, (255, 100, 100))
        title_x = self.dialog_x + (self.dialog_w - title_surface.get_width()) // 2
        self.screen.blit(title_surface, (title_x, self.dialog_y + 20))
        
        # Attack info section
        attacker_name = getattr(self.caster, 'name', f"{self.caster.color.title()} Wizard")
        defender_name = getattr(self.wizard, 'name', f"{self.wizard.color.title()} Wizard")
        
        attack_info = f"{attacker_name} attacks {defender_name} for {self.damage} damage!"
        attack_surface = self.font.render(attack_info, True, (255, 200, 200))
        attack_x = self.dialog_x + (self.dialog_w - attack_surface.get_width()) // 2
        self.screen.blit(attack_surface, (attack_x, self.dialog_y + 70))
        
        # Defender's crystal reserves section
        reserves_title = f"{defender_name}'s Crystal Reserves:"
        reserves_surface = pygame.font.Font(None, 56).render(reserves_title, True, (200, 255, 200))
        reserves_x = self.dialog_x + (self.dialog_w - reserves_surface.get_width()) // 2
        self.screen.blit(reserves_surface, (reserves_x, self.dialog_y + 110))
        
        # Crystal selection area
        colors = ['red', 'blue', 'green', 'yellow', 'white']
        color_map = {
            'red': (255, 100, 100),
            'blue': (100, 150, 255),
            'green': (100, 255, 100),
            'yellow': (255, 255, 100),
            'white': (255, 255, 255)
        }
        
        crystal_section_y = self.dialog_y + 150
        
        for i, color in enumerate(colors):
            available = self.wizard.crystals.get(color, 0)
            if available == 0:
                continue  # Skip colors the wizard doesn't have
                
            # Calculate positions for this crystal type
            crystal_x = self.dialog_x + 60 + i * 110
            
            # Clickable crystal area
            crystal_rect = pygame.Rect(crystal_x, crystal_section_y + 10, 80, 60)
            is_selected = self.selected_crystal_color == color
            
            # Background highlighting for selected crystal
            if is_selected:
                pygame.draw.rect(self.screen, (100, 100, 150), crystal_rect, border_radius=8)
                pygame.draw.rect(self.screen, (255, 255, 100), crystal_rect, 3, border_radius=8)
            else:
                pygame.draw.rect(self.screen, (60, 60, 80), crystal_rect, border_radius=8)
                pygame.draw.rect(self.screen, (150, 150, 150), crystal_rect, 2, border_radius=8)
            
            # Crystal color indicator
            crystal_color = color_map[color]
            circle_y = crystal_section_y + 20
            pygame.draw.circle(self.screen, crystal_color, (crystal_x + 40, circle_y), 12)
            pygame.draw.circle(self.screen, (255, 255, 255), (crystal_x + 40, circle_y), 12, 2)
            
            # Color label
            color_label = color.title()
            label_surface = pygame.font.Font(None, 32).render(color_label, True, (255, 255, 255))
            label_x = crystal_x + 40 - label_surface.get_width() // 2
            self.screen.blit(label_surface, (label_x, crystal_section_y + 35))
            
            # Available count
            available_text = f"({available})"
            available_surface = pygame.font.Font(None, 28).render(available_text, True, (200, 200, 200))
            available_x = crystal_x + 40 - available_surface.get_width() // 2
            self.screen.blit(available_surface, (available_x, crystal_section_y + 50))
            
            # Selection indicator
            if is_selected:
                select_text = "SELECTED"
                select_surface = pygame.font.Font(None, 24).render(select_text, True, (255, 255, 100))
                select_x = crystal_x + 40 - select_surface.get_width() // 2
                self.screen.blit(select_surface, (select_x, crystal_section_y + 75))
        
        # Summary section
        summary_y = self.dialog_y + 280
        
        # Blocking summary - show new mechanics
        if self.total_selected > 0:
            summary_text = f"Selected: 1 {self.selected_crystal_color} crystal (blocks 1 damage)"
            summary_color = (100, 255, 100)
        else:
            summary_text = "No crystal selected (blocks 0 damage)"
            summary_color = (255, 200, 200)
        
        summary_surface = pygame.font.Font(None, 48).render(summary_text, True, summary_color)
        summary_x = self.dialog_x + (self.dialog_w - summary_surface.get_width()) // 2
        self.screen.blit(summary_surface, (summary_x, summary_y))
        
        # Damage preview - updated for 1 crystal = 1 damage blocked maximum
        damage_blocked = min(1, self.total_selected)  # Maximum 1 damage can be blocked
        final_damage = max(0, self.damage - damage_blocked)
        damage_preview = f"Incoming: {self.damage} damage → You take: {final_damage} damage"
        preview_color = (100, 255, 100) if damage_blocked > 0 else (255, 200, 200)
        preview_surface = pygame.font.Font(None, 44).render(damage_preview, True, preview_color)
        preview_x = self.dialog_x + (self.dialog_w - preview_surface.get_width()) // 2
        self.screen.blit(preview_surface, (preview_x, summary_y + 30))
        
        # Action buttons
        button_y = self.dialog_y + self.dialog_h - 60
        
        # Block button
        block_x = self.dialog_x + self.dialog_w // 2 - 120
        block_rect = pygame.Rect(block_x, button_y, 100, 40)
        block_enabled = True  # Always allow blocking (even 0 crystals)
        block_color = (0, 120, 200) if block_enabled else (80, 80, 80)
        pygame.draw.rect(self.screen, block_color, block_rect, border_radius=8)
        pygame.draw.rect(self.screen, (255, 255, 255), block_rect, 2, border_radius=8)
        
        block_text = "Confirm" if self.total_selected > 0 else "Block None"
        block_surface = pygame.font.Font(None, 44).render(block_text, True, (255, 255, 255))
        block_text_rect = block_surface.get_rect(center=block_rect.center)
        self.screen.blit(block_surface, block_text_rect)
        
        # Skip button (same as Block None, but more explicit)
        skip_x = self.dialog_x + self.dialog_w // 2 + 20
        skip_rect = pygame.Rect(skip_x, button_y, 100, 40)
        pygame.draw.rect(self.screen, (150, 50, 50), skip_rect, border_radius=8)
        pygame.draw.rect(self.screen, (255, 255, 255), skip_rect, 2, border_radius=8)
        
        skip_surface = pygame.font.Font(None, 44).render("Skip", True, (255, 255, 255))
        skip_text_rect = skip_surface.get_rect(center=skip_rect.center)
        self.screen.blit(skip_surface, skip_text_rect)
        
        # Instructions
        instruction_text = "Click on a crystal to select it (1 crystal blocks 1 damage max). Press Enter to confirm."
        instruction_surface = pygame.font.Font(None, 32).render(instruction_text, True, (180, 180, 180))
        instruction_x = self.dialog_x + (self.dialog_w - instruction_surface.get_width()) // 2
        self.screen.blit(instruction_surface, (instruction_x, self.dialog_y + self.dialog_h - 20))

class GameGUI:
    def __init__(self, game):
        """Initialize the game GUI to fill the entire screen in a closable window."""
        self.game = game
        # Set GUI reference in game for blocking dialogs
        game.gui = self

        if not pygame.get_init():
            pygame.init()

        info = pygame.display.Info()
        self.screen_width = info.current_w
        self.screen_height = info.current_h

        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height), pygame.RESIZABLE)
        pygame.display.set_caption("Crystal Wizards")

        pygame.font.init()
        self.font_small = pygame.font.Font(None, 25)
        self.font_medium = pygame.font.Font(None, 30)
        self.font_large = pygame.font.Font(None, 50)

        # Board layout
        self.board_center_x = self.screen_width // 2
        self.board_center_y = self.screen_height // 2
        self.center_radius = 30
        self.rect_distance = 80
        self.outer_distance = 150
        self.mine_distance = 220

        # UI state
        self.selected_wizard = None
        self.selected_spell_card = None
        self.show_spell_details = False

        self.highlight_manager = HighlightManager()
        self.sound_manager = sound_manager
        self.action_panel = ActionPanel(self.screen_width - 350, 280, self.font_medium)

        self.dice_manager = DiceRollManager(self.screen, self.font_large)
        self.is_dice_rolling = False
        self.pending_action = None

        self.sound_manager.load_sounds()

        self.current_action_mode = None
        
        # AI turn timing variables for non-blocking behavior
        self.ai_turn_start_time = 0
        self.ai_thinking_delay = AI_THINKING_DELAY  # Configurable delay before AI acts
        self.ai_turn_executed = False
        self.ai_action_delay = AI_ACTION_DELAY  # Configurable delay between AI actions
        self.ai_last_action_time = 0
        self.ai_actions_queue = []
        self.ai_current_action_index = 0

        self.position_coords = {}
        self.calculate_position_coordinates()

        # Spell card horizontal row layout state
        self.spell_card_rects = []
        self.visible_hand = []
        
        # Attack animation system
        self.attack_animations = []
        
        # Crystal return animation system
        self.crystal_return_animations = []
        self.hovered_card_index = None
        self.selected_card_index = None
        self.mouse_pos = (0, 0)
        
        # Enhanced visual systems
        self.last_frame_time = pygame.time.get_ticks()
        self.glow_effects = {}  # Track glowing elements
        self.ui_animations = {}  # Track UI animations

    
        # Blood Magic dialogs
        self.blood_magic_choice_dialog = BloodMagicChoiceDialog(self.screen, self.font_medium, self.font_large)
        self.blood_magic_dialog = BloodMagicDialog(self.screen, self.font_medium, self.font_large)
        
        # Pause Menu dialog
        self.pause_menu = PauseMenuDialog(self.screen, self.font_medium, self.font_large)
        
        # Load and scale background image
        self._load_background_image()

    def _is_blood_magic_choice_active(self):
        """Check if the Blood Magic choice dialog is currently active."""
        return hasattr(self, 'blood_magic_dialog') and self.blood_magic_dialog.visible

    def _load_background_image(self):
        """Load and scale the background image to fit the screen"""
        try:
            # Load the background image using resource_path for PyInstaller compatibility
            bg_path = resource_path("sounds/crystal_wizards_background.png")
            if bg_path.exists():
                self.bg_original = pygame.image.load(str(bg_path)).convert()
                # Scale to current screen size
                self.bg_scaled = pygame.transform.scale(self.bg_original, (self.screen_width, self.screen_height))
            else:
                print(f"Warning: Background image not found at {bg_path}")
                self.bg_original = None
                self.bg_scaled = self._create_fallback_background()
        except (pygame.error, FileNotFoundError) as e:
            print(f"Warning: Could not load background image: {e}")
            # Create a fallback gradient background
            self.bg_original = None
            self.bg_scaled = self._create_fallback_background()
        
    def _create_fallback_background(self):
        """Create a fallback gradient background if image loading fails"""
        surface = pygame.Surface((self.screen_width, self.screen_height))
        # Create a simple gradient from dark blue to light blue
        for y in range(self.screen_height):
            ratio = y / self.screen_height
            color_r = int(20 + (100 - 20) * ratio)
            color_g = int(30 + (150 - 30) * ratio)
            color_b = int(80 + (200 - 80) * ratio)
            pygame.draw.line(surface, (color_r, color_g, color_b), (0, y), (self.screen_width, y))
        return surface
    
    def _rescale_background(self):
        """Rescale the background image when window is resized"""
        if self.bg_original:
            self.bg_scaled = pygame.transform.scale(self.bg_original, (self.screen_width, self.screen_height))
        else:
            self.bg_scaled = self._create_fallback_background()

    # ---- Utility for name display ----
    def display_name(self, player):
        name = getattr(player, 'name', None)
        if name:
            return name
        # Fallback to color-based label
        base = f"{player.color.title()} Wizard"
        if isinstance(player, AIWizard):
            base += " (AI)"
        return base

    # ---- Basic helpers ----
    def show_blocking_dialog(self, wizard, damage, caster, game=None):
        """Show the dialog for blocking damage with crystals."""
        # Add attack animation before showing blocking dialog
        if wizard.location in self.position_coords:
            self.add_attack_animation(wizard.location)
        
        dialog = BlockingDialog(self.screen, self.font_medium, wizard, damage, caster, game)
        return dialog.run_modal()
    
    def add_attack_animation(self, position):
        """Add a sparkle attack animation at the given position"""
        if position in self.position_coords:
            x, y = self.position_coords[position]
            animation = {
                'x': x,
                'y': y,
                'start_time': pygame.time.get_ticks(),
                'duration': 1000,  # 1 second
                'particles': []
            }
            
            # Create sparkle particles
            import random
            for _ in range(15):
                particle = {
                    'x': x + random.randint(-30, 30),
                    'y': y + random.randint(-30, 30),
                    'vx': random.uniform(-2, 2),
                    'vy': random.uniform(-2, 2),
                    'life': 1.0,
                    'size': random.randint(2, 6),
                    'color': random.choice([(255, 255, 0), (255, 200, 0), (255, 255, 255), (255, 100, 100)])
                }
                animation['particles'].append(particle)
            
            self.attack_animations.append(animation)
    
    def update_attack_animations(self):
        """Update and remove expired attack animations"""
        current_time = pygame.time.get_ticks()
        
        for animation in self.attack_animations[:]:
            elapsed = current_time - animation['start_time']
            if elapsed >= animation['duration']:
                self.attack_animations.remove(animation)
                continue
            
            # Update particles
            progress = elapsed / animation['duration']
            for particle in animation['particles']:
                particle['x'] += particle['vx']
                particle['y'] += particle['vy']
                particle['life'] = 1.0 - progress
                particle['vy'] += 0.1  # Gravity effect
    
    def draw_attack_animations(self):
        """Draw all active attack animations"""
        for animation in self.attack_animations:
            for particle in animation['particles']:
                if particle['life'] > 0:
                    alpha = int(255 * particle['life'])
                    size = int(particle['size'] * particle['life'])
                    if size > 0:
                        # Create a surface with per-pixel alpha
                        particle_surface = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
                        color_with_alpha = (*particle['color'][:3], alpha)
                        pygame.draw.circle(particle_surface, color_with_alpha, (size, size), size)
                        self.screen.blit(particle_surface, (int(particle['x'] - size), int(particle['y'] - size)))
    
    def add_crystal_return_animation(self, from_pos, to_pos, color, count=1):
        """Add animation for crystals returning to the board"""
        if from_pos in self.position_coords and to_pos in self.position_coords:
            start_x, start_y = self.position_coords[from_pos]
            end_x, end_y = self.position_coords[to_pos]
            
            for i in range(count):
                animation = {
                    'start_x': start_x,
                    'start_y': start_y,
                    'end_x': end_x,
                    'end_y': end_y,
                    'current_x': start_x,
                    'current_y': start_y,
                    'color': color,
                    'start_time': pygame.time.get_ticks() + (i * 100),  # Stagger animations
                    'duration': 1500,  # 1.5 seconds
                    'started': False
                }
                self.crystal_return_animations.append(animation)
    
    def update_crystal_return_animations(self):
        """Update crystal return animations"""
        current_time = pygame.time.get_ticks()
        
        for animation in self.crystal_return_animations[:]:
            if not animation['started'] and current_time >= animation['start_time']:
                animation['started'] = True
            
            if not animation['started']:
                continue
                
            elapsed = current_time - animation['start_time']
            if elapsed >= animation['duration']:
                self.crystal_return_animations.remove(animation)
                continue
            
            # Smooth easing animation
            progress = elapsed / animation['duration']
            # Use easeInOutQuad for smooth motion
            if progress < 0.5:
                progress = 2 * progress * progress
            else:
                progress = 1 - 2 * (1 - progress) * (1 - progress)
            
            animation['current_x'] = animation['start_x'] + (animation['end_x'] - animation['start_x']) * progress
            animation['current_y'] = animation['start_y'] + (animation['end_y'] - animation['start_y']) * progress
    
    def draw_crystal_return_animations(self):
        """Draw crystal return animations"""
        for animation in self.crystal_return_animations:
            if animation['started']:
                # Draw crystal as a small colored circle
                color_map = {
                    'red': (255, 100, 100),
                    'blue': (100, 100, 255),
                    'green': (100, 255, 100),
                    'yellow': (255, 255, 100),
                    'white': (255, 255, 255)
                }
                color = color_map.get(animation['color'], (200, 200, 200))
                
                # Draw with a slight glow effect
                pygame.draw.circle(self.screen, color, 
                                 (int(animation['current_x']), int(animation['current_y'])), 8)
                pygame.draw.circle(self.screen, (255, 255, 255), 
                                 (int(animation['current_x']), int(animation['current_y'])), 8, 2)

    def calculate_position_coordinates(self):
        """Pre-calculate screen coordinates for all board positions using new layout"""
        self.position_coords['center'] = (self.board_center_x, self.board_center_y)

        self.position_coords.update({
            'rect_north': (self.board_center_x, self.board_center_y - self.rect_distance),
            'rect_south': (self.board_center_x, self.board_center_y + self.rect_distance),
            'rect_east': (self.board_center_x + self.rect_distance, self.board_center_y),
            'rect_west': (self.board_center_x - self.rect_distance, self.board_center_y)
        })

        for i in range(8):
            angle_rad = math.radians(i * 45)
            x = self.board_center_x + self.outer_distance * math.cos(angle_rad)
            y = self.board_center_y + self.outer_distance * math.sin(angle_rad)
            self.position_coords[f'hex_{i}'] = (int(x), int(y))

        self.position_coords.update({
            'mine_north': (self.board_center_x, self.board_center_y - self.mine_distance),
            'mine_south': (self.board_center_x, self.board_center_y + self.mine_distance),
            'mine_east': (self.board_center_x + self.mine_distance, self.board_center_y),
            'mine_west': (self.board_center_x - self.mine_distance, self.board_center_y)
        })

    # ---- Main loop and events ----
    def run(self):
        """Main game loop with enhanced visual systems"""
        clock = pygame.time.Clock()
        running = True

        self.game.initialize_game()

        while running:
            # Calculate delta time for smooth animations
            current_time = pygame.time.get_ticks()
            dt = (current_time - self.last_frame_time) / 1000.0  # Convert to seconds
            self.last_frame_time = current_time
            
            # Update visual systems
            particle_system.update(dt)
            animation_manager.update(dt)
            if not self.is_dice_rolling:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        result = self.pause_menu.run_modal()
                        if result == 'quit':
                            running = False
                            break
                        elif result == 'resume':
                            continue
                    elif event.type == pygame.MOUSEBUTTONDOWN:
                        # Check if Blood Magic dialogs should handle the event first
                        if hasattr(self, 'blood_magic_choice_dialog') and self.blood_magic_choice_dialog.handle_event(event):
                            continue
                        if hasattr(self, 'blood_magic_dialog') and self.blood_magic_dialog.handle_event(event):
                            continue
                        self.handle_mouse_click(event.pos)
                    elif event.type == pygame.MOUSEBUTTONUP:
                        # Handle mouse button up for Blood Magic dialogs (needed for Button class)
                        if hasattr(self, 'blood_magic_choice_dialog') and self.blood_magic_choice_dialog.handle_event(event):
                            continue
                        if hasattr(self, 'blood_magic_dialog') and self.blood_magic_dialog.handle_event(event):
                            continue
                    elif event.type == pygame.KEYDOWN:
                        # Check if Blood Magic dialogs should handle the event first
                        if hasattr(self, 'blood_magic_choice_dialog') and self.blood_magic_choice_dialog.handle_event(event):
                            continue
                        if hasattr(self, 'blood_magic_dialog') and self.blood_magic_dialog.handle_event(event):
                            continue
                        if event.key == pygame.K_ESCAPE:
                            result = self.pause_menu.run_modal()
                            if result == 'quit':
                                running = False
                                break
                            elif result == 'resume':
                                continue
                        else:
                            self.handle_key_press(event.key)
                    elif event.type == pygame.MOUSEMOTION:
                        # Handle mouse motion for Blood Magic dialogs
                        if hasattr(self, 'blood_magic_choice_dialog') and self.blood_magic_choice_dialog.handle_event(event):
                            continue
                        if hasattr(self, 'blood_magic_dialog') and self.blood_magic_dialog.handle_event(event):
                            continue
                    elif event.type == pygame.VIDEORESIZE:
                        self.handle_resize(event)

                    # Pass all events to action panel
                    self.handle_action_panel_event(event)
                
                # Handle AI failsafe events during AI turns
                current_player = self.game.get_current_player()
                if isinstance(current_player, AIWizard):
                    ai_action = self.action_panel.handle_ai_event(event)
                    if ai_action == 'ai_failsafe':
                        # Reset AI state to clear any frozen/stuck conditions
                        if hasattr(current_player, 'ai_controller') and current_player.ai_controller:
                            current_player.ai_controller.reset_state()
                        # Force end the AI turn
                        self.game.end_turn()
                        # Update button visibility for the new current player
                        new_current_player = self.game.get_current_player()
                        self.action_panel.set_ai_turn_state(isinstance(new_current_player, AIWizard))
                        self.sound_manager.play_sound('click', 0.8)

            current_player = self.game.get_current_player()
            if isinstance(current_player, AIWizard) and not self.game.game_over and not self.is_dice_rolling:
                current_time = pygame.time.get_ticks()
                
                # Check if this is a new AI turn
                if self.ai_turn_start_time == 0:
                    self.ai_turn_start_time = current_time
                    self.ai_turn_executed = False
                    self.ai_actions_queue = []
                    self.ai_current_action_index = 0
                    self.ai_last_action_time = 0
                
                # Process AI turn with animated actions
                self._process_ai_turn_with_animations(current_player, current_time)
            else:
                # Reset AI turn timer if not an AI turn
                self.ai_turn_start_time = 0
                self.ai_turn_executed = False

            self.draw()

            if self.is_dice_rolling:
                self.is_dice_rolling = self.dice_manager.update_and_draw(self.screen_width // 2, self.screen_height // 2)

            pygame.display.flip()
            clock.tick(60)

        pygame.quit()
        sys.exit()

    def handle_resize(self, event):
        """Handle window resize events for dynamic scaling"""
        self.screen_width, self.screen_height = event.w, event.h
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height), pygame.RESIZABLE)
        self.board_center_x = self.screen_width // 2
        self.board_center_y = self.screen_height // 2
        self.calculate_position_coordinates()
        self.action_panel = ActionPanel(self.screen_width - 350, 280, self.font_medium)
        # Rescale background image for new window size
        self._rescale_background()

    def handle_mouse_click(self, pos):
        """Handle mouse clicks on the game board and UI"""
        if self.game.game_over or self.is_dice_rolling:
            return

        current_player = self.game.get_current_player()
        if isinstance(current_player, AIWizard):
            return

        clicked_position = self.get_position_at_coordinates(pos)
        if clicked_position:
            self.handle_board_click(clicked_position, current_player)

        self.handle_ui_click(pos, current_player)

    def handle_action_panel_event(self, event):
        """Handle action panel events"""
        action = self.action_panel.handle_event(event, self.game)
        current_player = self.game.get_current_player()

        if action == 'move_selected':
            self.current_action_mode = 'move' if self.current_action_mode != 'move' else None
            if self.current_action_mode == 'move':
                adjacent_positions = self.game.board.get_adjacent_positions(current_player.location)
                self.highlight_manager.set_move_highlights(adjacent_positions)
            else:
                self.highlight_manager.clear_highlights()

        elif action == 'mine_selected':
            self.current_action_mode = 'mine' if self.current_action_mode != 'mine' else None
            if self.current_action_mode == 'mine':
                mineable = self.game.board.get_mineable_positions(current_player.location)
                self.highlight_manager.set_mine_highlights(mineable)
            else:
                self.highlight_manager.clear_highlights()

        elif action == 'cast_selected':
            self.current_action_mode = 'cast' if self.current_action_mode != 'cast' else None
            if self.current_action_mode == 'cast':
                castable = self.game.board.get_castable_positions(current_player.location)
                self.highlight_manager.set_cast_highlights(castable)
            else:
                self.highlight_manager.clear_highlights()

        elif action == 'end_turn':
            self.game.end_turn()
            # Update button visibility for the new current player
            new_current_player = self.game.get_current_player()
            self.action_panel.set_ai_turn_state(isinstance(new_current_player, AIWizard))
            self.current_action_mode = None
            self.highlight_manager.clear_highlights()
            self.sound_manager.play_sound('click', 0.8)

        elif action == 'ai_failsafe':
            # Force end the AI turn
            self.game.end_turn()
            # Update button visibility for the new current player
            new_current_player = self.game.get_current_player()
            self.action_panel.set_ai_turn_state(isinstance(new_current_player, AIWizard))
            self.sound_manager.play_sound('click', 0.8)
            

    def get_position_at_coordinates(self, screen_pos):
        """Find which board position was clicked"""
        click_x, click_y = screen_pos

        for position, (x, y) in self.position_coords.items():
            distance = math.sqrt((click_x - x) ** 2 + (click_y - y) ** 2)
            if distance <= 25:
                return position

        return None

    def handle_board_click(self, position, current_player):
        """Handle clicks on board positions"""
        if self.current_action_mode == 'cast':
            if self.highlight_manager.is_highlighted(position):
                if self.selected_spell_card:
                    # Create spell casting visual effects
                    caster_pos = current_player.location
                    if caster_pos in self.position_coords:
                        caster_x, caster_y = self.position_coords[caster_pos]
                        
                        # Determine spell color based on crystals used
                        spell_colors = []
                        for color, count in self.selected_spell_card.original_crystals_used.items():
                            if count > 0:
                                spell_colors.extend([color] * count)
                        
                        primary_color = spell_colors[0] if spell_colors else 'white'
                        
                        # Create casting effect at caster position
                        particle_system.create_spell_cast_effect(caster_x, caster_y, primary_color, 30)
                        
                        # Create spell trail to all targets
                        adjacent_positions = self.game.board.get_adjacent_positions(caster_pos)
                        for target_pos in adjacent_positions:
                            if target_pos in self.position_coords:
                                target_x, target_y = self.position_coords[target_pos]
                                wizards_at_pos = self.game.board.get_wizard_at_position(target_pos)
                                if wizards_at_pos and any(w != current_player for w in wizards_at_pos):
                                    particle_system.create_spell_trail_effect(
                                        caster_x, caster_y, target_x, target_y, primary_color
                                    )
                    
                    if self.game.cast_spell(current_player, self.selected_spell_card, self):
                        self.sound_manager.play_sound('spell_cast', 0.8)
                        self.current_action_mode = None
                        self.highlight_manager.clear_highlights()
                        self.selected_spell_card = None
                    else:
                        print("Failed to cast spell.")
                return

        if self.current_action_mode == 'move':
            if self.highlight_manager.is_highlighted(position):
                # Create movement animation
                old_location = current_player.location
                if old_location in self.position_coords and position in self.position_coords:
                    old_x, old_y = self.position_coords[old_location]
                    new_x, new_y = self.position_coords[position]
                    wizard_id = f"{current_player.color}_{id(current_player)}"
                    animation_manager.start_wizard_movement(wizard_id, (old_x, old_y), (new_x, new_y), 0.5)
                
                if self.game.move_player(current_player, position):
                    self.sound_manager.play_move()
                    self.current_action_mode = None
                    self.highlight_manager.clear_highlights()
                    if self.action_panel.selected_action == 'move':
                        adjacent_positions = self.game.board.get_adjacent_positions(current_player.location)
                        self.highlight_manager.set_move_highlights(adjacent_positions)
                return

        if self.current_action_mode == 'mine':
            if self.highlight_manager.is_highlighted(position):
                self.initiate_mine_sequence(current_player, position)
                return
        
        if self.current_action_mode == 'teleport_choice':
            print(f"DEBUG: In teleport_choice mode, clicked position: {position}")
            print(f"DEBUG: Is position highlighted? {self.highlight_manager.is_highlighted(position)}")
            if self.highlight_manager.is_highlighted(position):
                print(f"DEBUG: Completing teleportation to {position}")
                # Complete the teleportation to the chosen position
                self.complete_teleportation(self.teleport_choice_player, position)
                return
            else:
                print(f"DEBUG: Position not highlighted, ignoring click")


    def initiate_mine_sequence(self, player, position):
        """Starts the dice rolling animation for a mining action with visual effects."""
        if not self.game.can_mine(player):
            return

        # Create mining visual effects
        if position in self.position_coords:
            mine_x, mine_y = self.position_coords[position]
            
            # Determine crystal color being mined
            crystal_color = 'white'  # Default for white crystals
            if self.game.board.is_mine(position):
                mine_color = self.game.board.get_mine_color_from_position(position)
                if mine_color and mine_color != 'white':
                    crystal_color = mine_color
            
            # Create mining particle effect
            particle_system.create_mining_effect(mine_x, mine_y, crystal_color)

        if position in self.game.board.white_crystals and self.game.board.white_crystals[position] > 0:
            result = self.game.mine_white_crystal(player, position)
            if result == "reserve_full":
                self.show_reserve_full_warning()
            elif result:
                # Create crystal pickup effect
                if position in self.position_coords:
                    mine_x, mine_y = self.position_coords[position]
                    particle_system.create_crystal_pickup_effect(mine_x, mine_y, 'white')
                
                self.sound_manager.play_mine()
                self.current_action_mode = None
                self.highlight_manager.clear_highlights()
            return

        # Check for Blood Magic opportunity (matching color mine for human players)
        if (self.game.board.is_mine(position) and 
            not isinstance(player, AIWizard)):
            
            mine_color = self.game.board.get_mine_color_from_position(position)
            if mine_color and (mine_color == player.color or mine_color == 'white'):
                # Show Blood Magic choice dialog
                self.show_blood_magic_choice(player, position)
                return

        self.is_dice_rolling = True
        self.pending_action = {'player': player, 'position': position}

        if self.game.board.is_mine(position):
            if position == 'center':
                # White mine uses healing dice (with updated values)
                self.dice_manager.roll_healing_dice(self.resolve_mine_sequence)
            else:
                # Regular colored mines use standard dice
                self.dice_manager.roll_mine_dice(self.resolve_mine_sequence)
        else:
            self.is_dice_rolling = False
            self.pending_action = None

    def resolve_mine_sequence(self, roll_result):
        """Callback executed after dice animation finishes."""
        self.is_dice_rolling = False
        if not self.pending_action:
            return

        player = self.pending_action['player']
        position = self.pending_action['position']

        old_health = player.health
        old_location = player.location

        success = self.game.resolve_mine_with_roll(player, position, roll_result)

        if success == "reserve_full":
            self.show_reserve_full_warning()
        elif success:
            # Create success visual effects
            if position in self.position_coords:
                mine_x, mine_y = self.position_coords[position]
                
                # Determine what was mined
                if self.game.board.is_mine(position):
                    mine_color = self.game.board.get_mine_color_from_position(position)
                    crystal_color = mine_color if mine_color else 'white'
                else:
                    crystal_color = 'white'
                
                # Create crystal pickup effect
                particle_system.create_crystal_pickup_effect(mine_x, mine_y, crystal_color)
            
            if player.health > old_health:
                self.sound_manager.play_heal()
            if player.location != old_location:
                self.sound_manager.play_teleport()
            elif position != 'center':
                self.sound_manager.play_mine()
            
            # Handle white mine teleportation choice
            print(f"DEBUG: Checking teleport condition - position: {position}, player.location: {player.location}, old_location: {old_location}")
            if position == 'center' and player.location == old_location:
                print(f"DEBUG: Teleport condition met! Calling show_teleportation_choice_dialog")
                # Player mined from center but didn't teleport yet - choice needed
                self.show_teleportation_choice_dialog(player)
                return  # Don't clear pending action until teleportation is complete
            else:
                print(f"DEBUG: Teleport condition NOT met")

        self.pending_action = None
        self.current_action_mode = None
        self.highlight_manager.clear_highlights()

    def show_teleportation_choice_dialog(self, player):
        """Show teleportation choice for white mine - highlight outer hex positions for selection."""
        print(f"DEBUG: show_teleportation_choice_dialog called for player {player.color}")
        
        # Get all outer hex positions
        outer_hex_positions = self.game.board.layout.get_outer_ring_positions()
        print(f"DEBUG: Outer hex positions: {outer_hex_positions}")
        
        # Check if this is an AI player
        if hasattr(player, 'ai') and player.ai is not None:
            print(f"DEBUG: AI player detected, making automatic teleportation choice")
            # AI automatically chooses a teleportation destination
            available_positions = [pos for pos in outer_hex_positions if len(self.game.board.get_wizard_at_position(pos)) == 0]
            
            if available_positions:
                # AI chooses based on strategic value
                chosen_position = self._ai_choose_teleport_destination(player, available_positions)
                print(f"DEBUG: AI chose to teleport to {chosen_position}")
                self.complete_teleportation(player, chosen_position)
                return
            else:
                print(f"DEBUG: No available teleportation positions, AI stays at center")
                # No valid teleportation positions, clear state and continue
                self.pending_action = None
                self.current_action_mode = None
                self.highlight_manager.clear_highlights()
                return
        
        # Human player - set up GUI for manual selection
        # Highlight all outer hex positions for selection
        self.highlight_manager.set_teleport_highlights(outer_hex_positions)
        print(f"DEBUG: Set teleport highlights for {len(outer_hex_positions)} positions")
        
        # Set current mode to teleportation choice
        self.current_action_mode = 'teleport_choice'
        self.teleport_choice_player = player
        print(f"DEBUG: Set action mode to 'teleport_choice'")
        
        # Add visual feedback
        self.game.action_log.append(f"Click on an outer hex space to teleport to!")
        print(f"DEBUG: Added message to action log")
    
    def _ai_choose_teleport_destination(self, player, available_positions):
        """AI logic to choose the best teleportation destination."""
        if not available_positions:
            return None
            
        best_position = None
        best_score = -1000
        
        for position in available_positions:
            score = 0
            
            # Score based on resources at position
            if self.game.board.has_crystals_at_position(position):
                score += 30  # White crystals are valuable
                
            if self.game.board.is_mine(position):
                mine_color = self.game.board.get_mine_color_from_position(position)
                if mine_color == player.color:
                    score += 40  # Prefer own color mine
                else:
                    score += 20  # Any mine is decent
                    
            # Score based on distance from enemies (defensive)
            enemies = [p for p in self.game.players if p != player]
            min_enemy_distance = float('inf')
            for enemy in enemies:
                try:
                    distance = self.game.board.get_distance(position, enemy.location)
                    min_enemy_distance = min(min_enemy_distance, distance)
                except:
                    distance = 3  # Default safe distance if calculation fails
                    
            if min_enemy_distance == float('inf'):
                min_enemy_distance = 3  # No enemies found, assume safe
                
            # Prefer positions not too close to enemies (but not too far either)
            if min_enemy_distance >= 2:
                score += 10  # Safe distance
            elif min_enemy_distance >= 3:
                score += 5   # Maybe too far from action
                
            # Add small random factor to prevent predictability
            score += random.randint(-5, 5)
            
            if score > best_score:
                best_score = score
                best_position = position
                
        return best_position if best_position else random.choice(available_positions)

    def complete_teleportation(self, player, target_position):
        """Complete the teleportation after player choice with animation."""
        old_location = player.location
        
        # Create teleportation visual effects
        if old_location in self.position_coords:
            old_x, old_y = self.position_coords[old_location]
            particle_system.create_spell_cast_effect(old_x, old_y, 'wild', 25)
            
        if target_position in self.position_coords:
            new_x, new_y = self.position_coords[target_position]
            particle_system.create_spell_cast_effect(new_x, new_y, 'wild', 25)
            
            # Create movement animation
            wizard_id = f"{player.color}_{id(player)}"
            if old_location in self.position_coords:
                old_x, old_y = self.position_coords[old_location]
                animation_manager.start_wizard_movement(wizard_id, (old_x, old_y), (new_x, new_y), 0.8)
        
        # Perform the teleportation
        self.game.board.remove_wizard_from_position(old_location, player)
        player.location = target_position
        self.game.board.add_wizard_to_position(target_position, player)
        
        # Log and play sound
        self.game.action_log.append(f"{player.color.title()} teleported to {target_position}!")
        self.sound_manager.play_teleport()
        
        # Clear the action state
        self.pending_action = None
        self.current_action_mode = None
        self.teleport_choice_player = None
        self.highlight_manager.clear_highlights()

    def show_reserve_full_warning(self):
        """Show visual feedback for reserve full (placeholder)."""
        pass

    def show_blood_magic_choice(self, player, position):
        """Show the Blood Magic choice dialog and handle the result."""
        def on_choice_made(choice):
            if choice == 'blood_magic':
                self.initiate_blood_magic_sequence(player, position)
            else:
                # Regular mining
                self.initiate_regular_mine_sequence(player, position)
        
        # Initialize dialogs if not already done
        if not hasattr(self, 'blood_magic_choice_dialog'):
            self.blood_magic_choice_dialog = BloodMagicChoiceDialog(self.screen, self.font_medium, self.font_large)
        if not hasattr(self, 'blood_magic_dialog'):
            self.blood_magic_dialog = BloodMagicDialog(self.screen, self.font_medium, self.font_large)
        
        self.blood_magic_choice_dialog.show(on_choice_made)

    def initiate_blood_magic_sequence(self, player, position):
        """Handle Blood Magic mining with two dice."""
        import random
        
        # Roll two dice - use healing dice for white mine, regular dice for colored mines
        if position == 'center':
            # White mine uses healing dice (3, 2, 2, 1, 1, 1)
            healing_die_faces = [3, 2, 2, 1, 1, 1]
            dice1 = random.choice(healing_die_faces)
            dice2 = random.choice(healing_die_faces)
        else:
            # Regular colored mines use standard dice
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
        
        def on_dice_assignment(mining_die, health_die):
            # Apply health - set to die result (Blood Magic risk/reward mechanic)
            old_health = player.health
            old_location = player.location
            player.health = health_die  # Set health to die result, not add to it
            health_change = health_die - old_health
            
            # Create appropriate log message based on health change
            if health_change > 0:
                self.game.action_log.append(f"{player.color.title()} Wizard's health set to {health_die} (↑{health_change}) from Blood Magic!")
            elif health_change < 0:
                self.game.action_log.append(f"{player.color.title()} Wizard's health set to {health_die} (↓{abs(health_change)}) from Blood Magic!")
            else:
                self.game.action_log.append(f"{player.color.title()} Wizard's health remains {health_die} from Blood Magic!")
            
            # Set up pending action for teleportation handling (same as regular mining)
            self.pending_action = {'player': player, 'position': position}
            
            # Then resolve mining with the chosen die
            success = self.game.resolve_mine_with_roll(player, position, mining_die)
            
            if success == "reserve_full":
                self.show_reserve_full_warning()
                # Clear pending action on failure
                self.pending_action = None
                self.current_action_mode = None
                self.highlight_manager.clear_highlights()
            elif success:
                if player.health > old_health:
                    self.sound_manager.play_heal()
                if player.location != old_location:
                    self.sound_manager.play_teleport()
                elif position != 'center':
                    self.sound_manager.play_mine()
                
                self.game.action_log.append(f"{player.color.title()} Wizard used Blood Magic! Health: {health_die}, Mining: {mining_die}")
                
                # Handle white mine teleportation choice (same as regular mining)
                print(f"DEBUG: Blood Magic - Checking teleport condition - position: {position}, player.location: {player.location}, old_location: {old_location}")
                if position == 'center' and player.location == old_location:
                    print(f"DEBUG: Blood Magic - Teleport condition met! Calling show_teleportation_choice_dialog")
                    # Player mined from center but didn't teleport yet - choice needed
                    self.show_teleportation_choice_dialog(player)
                    return  # Don't clear pending action until teleportation is complete
                else:
                    print(f"DEBUG: Blood Magic - Teleport condition NOT met")
                
                # Clear pending action if no teleportation needed
                self.pending_action = None
                self.current_action_mode = None
                self.highlight_manager.clear_highlights()
            else:
                # Clear pending action on failure
                self.pending_action = None
                self.current_action_mode = None
                self.highlight_manager.clear_highlights()
        
        # Show the Blood Magic dialog for dice assignment
        self.blood_magic_dialog.show(dice1, dice2, player.color, on_dice_assignment)

    def initiate_regular_mine_sequence(self, player, position):
        """Handle regular mining (single die)."""
        self.is_dice_rolling = True
        self.pending_action = {'player': player, 'position': position}
        
        if self.game.board.is_mine(position):
            if position == 'center':
                # White mine uses healing dice (3, 2, 2, 1, 1, 1)
                self.dice_manager.roll_healing_dice(self.resolve_mine_sequence)
            else:
                # Regular colored mines use standard dice
                self.dice_manager.roll_mine_dice(self.resolve_mine_sequence)
        else:
            self.is_dice_rolling = False
            self.pending_action = None

    def handle_ui_click(self, pos, current_player):
        """Handle clicks on UI elements"""
        clicked_card_index = self.get_spell_card_fan_click(pos, current_player)
        if clicked_card_index is not None:
            return

        if self.selected_spell_card:
            crystal_clicked = self.get_crystal_placement_click(pos, current_player)
            if crystal_clicked:
                return

    def get_spell_card_fan_click(self, pos, current_player):
        """Check if click was on any spell card in the fan layout"""
        for i, rect in enumerate(self.spell_card_rects):
            if rect and rect.collidepoint(pos):
                if i < len(current_player.hand):
                    card = current_player.hand[i]
                    if card not in current_player.cards_laid_down:
                        current_player.lay_down_spell_card(i)
                        self.sound_manager.play_sound('click', 0.8)
                elif i - len(current_player.hand) < len(current_player.cards_laid_down):
                    card_index = i - len(current_player.hand)
                    self.selected_spell_card = current_player.cards_laid_down[card_index]
                    self.sound_manager.play_sound('click', 0.8)
                return i
        return None

    def get_crystal_placement_click(self, pos, current_player):
        """Check if click was on crystal placement UI"""
        crystal_area_x = int(self.screen_width * 0.75)
        crystal_area_y = int(self.screen_height * 0.45)

        colors = ['red', 'blue', 'green', 'yellow', 'white']
        for i, color in enumerate(colors):
            crystal_x = crystal_area_x + i * 35
            crystal_y = crystal_area_y
            if (crystal_x <= pos[0] <= crystal_x + 30 and crystal_y <= pos[1] <= crystal_y + 30):
                if color != 'white' and current_player.crystals[color] > 0:
                    if self.selected_spell_card.add_crystals(color, 1, current_player):
                        self.sound_manager.play_charge()
                        return True
                elif color == 'white' and current_player.crystals['white'] > 0:
                    spell = self.selected_spell_card
                    for target_color in spell.cost:
                        needed = spell.cost[target_color] - spell.crystals_used.get(target_color, 0)
                        if needed > 0:
                            if spell.add_crystals('white', 1, current_player):
                                self.sound_manager.play_charge()
                                return True
                            break
        return False

    def handle_key_press(self, key):
        """Handle keyboard input"""
        if self.is_dice_rolling:
            return
        if key == pygame.K_SPACE:
            self.game.end_turn()
            # Update button visibility for the new current player
            new_current_player = self.game.get_current_player()
            self.action_panel.set_ai_turn_state(isinstance(new_current_player, AIWizard))
        # Esc is handled by quit dialog in the event loop

    # ---- Drawing ----
    def draw(self):
        """Draw the entire game state with enhanced visual effects"""
        # Apply screen shake offset
        shake_x, shake_y = particle_system.get_screen_offset()
        
        # Create a temporary surface for shake effect
        if shake_x != 0 or shake_y != 0:
            temp_surface = pygame.Surface((self.screen_width, self.screen_height))
            original_screen = self.screen
            self.screen = temp_surface
        
        # Draw background image first
        if hasattr(self, 'bg_scaled') and self.bg_scaled:
            self.screen.blit(self.bg_scaled, (0, 0))
        else:
            # Fallback to solid color if background not loaded
            self.screen.fill(COLORS['light_grey'])

        # Draw semi-transparent grey overlay behind the board for better visibility
        self.draw_board_overlay()

        self.update_blocking_highlights()
        self.update_attack_animations()
        self.update_crystal_return_animations()
        self.draw_board()
        self.draw_attack_animations()
        self.draw_crystal_return_animations()
        
        # Draw particle effects
        particle_system.draw(self.screen)
        
        self.draw_ui()
        
        # Apply screen shake if needed
        if shake_x != 0 or shake_y != 0:
            original_screen.fill((0, 0, 0))  # Clear with black
            original_screen.blit(temp_surface, (int(shake_x), int(shake_y)))
            self.screen = original_screen
        
        # Draw AI failsafe button during AI turns
        current_player = self.game.get_current_player()
        if isinstance(current_player, AIWizard) and not self.game.game_over:
            self.action_panel.draw_ai_buttons(self.screen)

        # Draw Blood Magic dialogs
        if hasattr(self, 'blood_magic_choice_dialog'):
            self.blood_magic_choice_dialog.draw()
        if hasattr(self, 'blood_magic_dialog'):
            self.blood_magic_dialog.draw()

        if self.game.game_over:
            self.draw_game_over()

    def update_blocking_highlights(self):
        """Update blocking highlights and remove expired ones."""
        current_time = pygame.time.get_ticks()
        
        # Check all wizards for expired blocking highlights
        for wizard in self.game.players:
            if getattr(wizard, 'is_blocking_highlighted', False):
                highlight_start = getattr(wizard, 'blocking_highlight_timer', 0)
                if current_time - highlight_start > 1000:  # 1 second
                    wizard.is_blocking_highlighted = False
                    wizard.blocking_highlight_timer = 0

    def draw_board_overlay(self):
        """Draw a semi-transparent grey overlay behind the board for better visibility"""
        # Calculate overlay dimensions based on board layout
        # The mines are the furthest elements at mine_distance from center
        padding = 60  # Extra padding around the board
        overlay_size = (self.mine_distance + padding) * 2
        
        # Calculate overlay position (centered on board)
        overlay_x = self.board_center_x - overlay_size // 2
        overlay_y = self.board_center_y - overlay_size // 2
        
        # Create semi-transparent surface
        overlay = pygame.Surface((overlay_size, overlay_size), pygame.SRCALPHA)
        overlay.fill((128, 128, 128, 120))  # Grey with 120/255 alpha (semi-transparent)
        
        # Draw the overlay
        self.screen.blit(overlay, (overlay_x, overlay_y))

    def draw_board(self):
        """Draw the game board with new clean layout"""
        self.draw_connections()

        for position, coords in self.position_coords.items():
            self.highlight_manager.draw_highlight(self.screen, position, coords)

        for position, coords in self.position_coords.items():
            self.draw_position(position, coords)

        self.draw_wizards()

    def draw_connections(self):
        """Draw clean lines connecting adjacent board positions"""
        drawn_connections = set()
        connections = self.game.board.layout.connections

        for position, adjacent_list in connections.items():
            if position in self.position_coords:
                start_pos = self.position_coords[position]
                for adjacent in adjacent_list:
                    if adjacent in self.position_coords:
                        connection_id = tuple(sorted([position, adjacent]))
                        if connection_id not in drawn_connections:
                            drawn_connections.add(connection_id)
                            end_pos = self.position_coords[adjacent]
                            pygame.draw.line(self.screen, COLORS['white'], start_pos, end_pos, 4)

    def draw_position(self, position, coords):
        """Draw a single board position with correct shape and color"""
        x, y = coords

        if position == 'center':
            # Draw white mine
            pygame.draw.circle(self.screen, COLORS['white'], (x, y), 35)
            pygame.draw.circle(self.screen, COLORS['black'], (x, y), 35, 2)
            # Show crystal count for white mine
            mine_color = self.game.board.get_mine_color_from_position(position)
            if mine_color:
                crystal_count = self.game.board.mines[mine_color]['crystals']
                text = self.font_small.render(str(crystal_count), True, COLORS['black'])
                text_rect = text.get_rect(center=(x, y))
                self.screen.blit(text, text_rect)

        elif position.startswith('rect_'):
            color_map = {
                'rect_north': COLORS['green'],
                'rect_south': COLORS['yellow'],
                'rect_east': COLORS['red'],
                'rect_west': COLORS['blue']
            }
            color = color_map.get(position, COLORS['grey'])
            pygame.draw.rect(self.screen, color, (x - 30, y - 22, 60, 45))
            pygame.draw.rect(self.screen, COLORS['black'], (x - 30, y - 22, 60, 45), 2)

        elif position.startswith('hex_'):
            self.draw_hexagon(x, y, 30, COLORS['grey'], COLORS['black'])
            # Determine crystal count from canonical storage
            crystal_count = 0
            pos_data = self.game.board.positions.get(position)
            if pos_data:
                # for mines, show count from board.mines; for hexes/center use positions[...] crystals
                if pos_data.get('type') == 'mine' or pos_data.get('type') == 'white_mine':
                    mine_color = self.game.board.get_mine_color_from_position(position)
                    if mine_color:
                        crystal_count = self.game.board.mines.get(mine_color, {}).get('crystals', 0)
                else:
                    crystal_count = pos_data.get('crystals', 0)

            # Draw crystal indicator if crystals exist with enhanced visuals
            if crystal_count > 0:
                # Create a glowing crystal effect
                current_time = pygame.time.get_ticks()
                pulse = 0.8 + 0.2 * abs(math.sin(current_time * 0.003))
                
                # Draw multiple layers for glow effect
                for i in range(3):
                    alpha = int(80 * pulse * (1 - i * 0.3))
                    radius = int(12 + i * 2)
                    glow_surface = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                    pygame.draw.circle(glow_surface, (255, 255, 255, alpha), (radius, radius), radius)
                    self.screen.blit(glow_surface, (coords[0] - radius, coords[1] - radius))
                
                # Draw main crystal
                pygame.draw.circle(self.screen, (255, 255, 255), coords, 10)
                pygame.draw.circle(self.screen, (200, 200, 255), coords, 8)
                
                # Draw count text with better visibility
                if crystal_count > 1:
                    font = self.font_small
                    text = font.render(str(crystal_count), True, (0, 0, 0))
                    # Add text outline for better visibility
                    outline_text = font.render(str(crystal_count), True, (255, 255, 255))
                    for dx, dy in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
                        outline_rect = outline_text.get_rect(center=(coords[0] + dx, coords[1] + dy))
                        self.screen.blit(outline_text, outline_rect)
                    text_rect = text.get_rect(center=coords)
                    self.screen.blit(text, text_rect)

        elif position.startswith('mine_'):
            color_map = {
                'mine_north': COLORS['yellow'],
                'mine_south': COLORS['green'],
                'mine_west': COLORS['red'],
                'mine_east': COLORS['blue']
            }
            color = color_map.get(position, COLORS['grey'])
            
            # Enhanced mine drawing with glow effect
            current_time = pygame.time.get_ticks()
            pulse = 0.9 + 0.1 * abs(math.sin(current_time * 0.002))
            
            # Draw glow layers
            for i in range(3):
                alpha = int(60 * pulse * (1 - i * 0.4))
                radius = int(32 + i * 3)
                glow_surface = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
                glow_color = (*color[:3], alpha)
                pygame.draw.circle(glow_surface, glow_color, (radius, radius), radius)
                self.screen.blit(glow_surface, (x - radius, y - radius))
            
            # Draw main mine circle
            pygame.draw.circle(self.screen, color, (x, y), 30)
            pygame.draw.circle(self.screen, COLORS['black'], (x, y), 30, 4)
            
            # Add inner highlight for depth
            highlight_color = tuple(min(255, c + 50) for c in color[:3])
            pygame.draw.circle(self.screen, highlight_color, (x - 8, y - 8), 12)

            mine_color = self.game.board.get_mine_color_from_position(position)
            if mine_color:
                crystal_count = self.game.board.mines[mine_color]['crystals']
                # Enhanced text with outline
                text = self.font_large.render(str(crystal_count), True, COLORS['white'])
                outline_text = self.font_large.render(str(crystal_count), True, COLORS['black'])
                
                # Draw text outline
                for dx, dy in [(-2, -2), (-2, 2), (2, -2), (2, 2)]:
                    outline_rect = outline_text.get_rect(center=(x + dx, y + dy))
                    self.screen.blit(outline_text, outline_rect)
                
                text_rect = text.get_rect(center=(x, y))
                self.screen.blit(text, text_rect)

            # Map position to color name
            position_to_color = {
                'mine_north': 'Yellow',
                'mine_south': 'Green', 
                'mine_east': 'Blue',
                'mine_west': 'Red'
            }
            color_name = position_to_color.get(position, 'Unknown')
            mine_label = f"{color_name} Mine"
            label_text = self.font_small.render(mine_label, True, COLORS['black'])
            label_rect = label_text.get_rect(center=(x, y - 45))
            self.screen.blit(label_text, label_rect)

    def draw_hexagon(self, x, y, radius, fill_color, border_color):
        """Draw a hexagon shape"""
        points = []
        for i in range(6):
            angle = math.radians(i * 60)
            px = x + radius * math.cos(angle)
            py = y + radius * math.sin(angle)
            points.append((px, py))

        pygame.draw.polygon(self.screen, fill_color, points)
        pygame.draw.polygon(self.screen, border_color, points, 2)

    def draw_wizards(self):
        """Draw wizard pieces on the board with sprites and animations - ROBUST VERSION"""
        try:
            # Validate that we have the necessary game state
            if not self.game or not self.game.board:
                return
                
            # STEP 1: Safely collect wizard data with extensive validation
            position_wizards = {}
            
            # Get a safe copy of wizards_on_board to avoid issues with concurrent modification
            try:
                wizards_data = dict(self.game.board.wizards_on_board)
            except (AttributeError, RuntimeError):
                # If we can't safely get the data, skip this frame
                return
            
            # Process each position's wizard data
            for position, data in wizards_data.items():
                # Skip invalid positions
                if not position or position not in self.position_coords:
                    continue
                    
                # Validate wizard data
                if not data:
                    continue
                    
                # Handle both list and single wizard formats
                try:
                    if isinstance(data, list):
                        # Filter out None/invalid wizards
                        valid_wizards = [w for w in data if w is not None and hasattr(w, 'color') and hasattr(w, 'location')]
                        if valid_wizards:
                            position_wizards[position] = valid_wizards
                    else:
                        # Single wizard - validate it
                        if data is not None and hasattr(data, 'color') and hasattr(data, 'location'):
                            position_wizards[position] = [data]
                except (AttributeError, TypeError):
                    # Skip corrupted wizard data
                    continue

            # STEP 2: Draw wizards with duplicate prevention and error handling
            processed_wizards = set()
            
            for position, wizards in position_wizards.items():
                try:
                    # Get position coordinates
                    x, y = self.position_coords[position]
                    count = len(wizards)
                    
                    # Calculate offsets for multiple wizards at same position
                    if count == 1:
                        offsets = [(0, -5)]
                    elif count == 2:
                        offsets = [(-16, -5), (16, -5)]
                    else:
                        # For 3+ wizards, arrange in a circle
                        offsets = []
                        radius = min(20, max(12, count * 3))  # Adaptive radius
                        for i in range(count):
                            angle = math.radians(i * (360 / count))
                            offset_x = int(radius * math.cos(angle))
                            offset_y = int(radius * math.sin(angle)) - 5
                            offsets.append((offset_x, offset_y))

                    # Draw each wizard at this position
                    for i, wizard in enumerate(wizards):
                        try:
                            # Validate wizard object
                            if not wizard or not hasattr(wizard, 'color'):
                                continue
                                
                            wizard_obj_id = id(wizard)
                            
                            # Prevent duplicate rendering
                            if wizard_obj_id in processed_wizards:
                                continue
                            processed_wizards.add(wizard_obj_id)
                            
                            # Calculate wizard position with bounds checking
                            if i < len(offsets):
                                offset_x, offset_y = offsets[i]
                            else:
                                # Fallback for unexpected extra wizards
                                angle = math.radians(i * 45)  # 45-degree spacing
                                offset_x = int(25 * math.cos(angle))
                                offset_y = int(25 * math.sin(angle)) - 5
                            
                            base_x, base_y = x + offset_x, y + offset_y
                            
                            # Check for movement animation
                            wizard_id = f"{wizard.color}_{wizard_obj_id}"
                            if (hasattr(self, 'animation_manager') and 
                                animation_manager.is_wizard_moving(wizard_id)):
                                wx, wy = animation_manager.get_wizard_position(wizard_id, (base_x, base_y))
                            else:
                                wx, wy = base_x, base_y
                            
                            # Get and validate wizard sprite
                            try:
                                sprite = sprite_manager.get_wizard_sprite(wizard.color)
                                if not sprite:
                                    continue
                            except (AttributeError, KeyError):
                                # Skip if sprite can't be loaded
                                continue
                            
                            # Apply visual effects if needed
                            try:
                                if (getattr(wizard, 'is_blocking_highlighted', False) or 
                                    wizard == self.selected_wizard):
                                    current_time = pygame.time.get_ticks()
                                    pulse_intensity = 0.5 + 0.5 * abs(math.sin(current_time * 0.005))
                                    
                                    if wizard == self.selected_wizard:
                                        glow_color = (255, 255, 100)  # Yellow glow for selected
                                    else:
                                        glow_color = COLORS['gold'][:3]  # Gold glow for blocking
                                    
                                    sprite = sprite_manager.create_glowing_sprite(sprite, glow_color, pulse_intensity)
                            except (AttributeError, KeyError, TypeError):
                                # Continue with regular sprite if glow effect fails
                                pass
                            
                            # Draw the wizard sprite
                            try:
                                sprite_rect = sprite.get_rect(center=(int(wx), int(wy)))
                                self.screen.blit(sprite, sprite_rect)
                            except (AttributeError, TypeError, ValueError):
                                # Skip this wizard if drawing fails
                                continue
                            
                            # Draw health indicator for damaged wizards
                            try:
                                if hasattr(wizard, 'health') and hasattr(wizard, 'max_health'):
                                    if wizard.health < wizard.max_health and wizard.max_health > 0:
                                        health_ratio = wizard.health / wizard.max_health
                                        bar_width = 20
                                        bar_height = 3
                                        bar_x = int(wx - bar_width // 2)
                                        bar_y = int(wy + 15)
                                        
                                        # Background bar
                                        pygame.draw.rect(self.screen, (100, 100, 100), 
                                                       (bar_x, bar_y, bar_width, bar_height))
                                        # Health bar
                                        health_width = int(bar_width * max(0, min(1, health_ratio)))
                                        health_color = (255, 100, 100) if health_ratio < 0.5 else (255, 200, 100)
                                        if health_width > 0:
                                            pygame.draw.rect(self.screen, health_color, 
                                                           (bar_x, bar_y, health_width, bar_height))
                            except (AttributeError, TypeError, ValueError, ZeroDivisionError):
                                # Skip health bar if calculation fails
                                pass
                                
                        except (AttributeError, TypeError, KeyError):
                            # Skip this wizard if any critical operation fails
                            continue
                            
                except (AttributeError, TypeError, KeyError, ValueError):
                    # Skip this position if processing fails
                    continue
                    
        except Exception as e:
            # Emergency fallback - log error but don't crash the game
            print(f"ERROR in draw_wizards: {e}")
            # Try to render at least something basic if possible
            try:
                for player in self.game.players:
                    if hasattr(player, 'location') and player.location in self.position_coords:
                        x, y = self.position_coords[player.location]
                        # Draw a simple colored circle as fallback
                        color_map = {'red': (255, 100, 100), 'blue': (100, 100, 255), 
                                   'green': (100, 255, 100), 'yellow': (255, 255, 100)}
                        color = color_map.get(player.color, (200, 200, 200))
                        pygame.draw.circle(self.screen, color, (int(x), int(y)), 8)
                        pygame.draw.circle(self.screen, (255, 255, 255), (int(x), int(y)), 8, 2)
            except:
                # If even the fallback fails, just return
                pass

    def draw_ui(self):
        """Draw the user interface"""
        self.draw_turn_indicator()
        self.draw_player_info()
        self.action_panel.draw(self.screen)
        self.draw_spell_cards_fan()
        self.draw_opponent_cards_area()
        self.draw_game_status_panel()

    def draw_turn_indicator(self):
        """Draw a clear turn indicator at the top of the screen"""
        current_player = self.game.get_current_player()

        indicator_width = int(self.screen_width * 0.6)
        pygame.draw.rect(self.screen, COLORS['white'], (10, 10, indicator_width, 50))
        pygame.draw.rect(self.screen, COLORS['black'], (10, 10, indicator_width, 50), 2)

        turn_text = f"{self.display_name(current_player)}'s Turn"
        text_surface = self.font_large.render(turn_text, True, COLORS['black'])
        self.screen.blit(text_surface, (20, 25))

        if self.current_action_mode:
            action_text = f"Action: {self.current_action_mode.title()}"
            action_surface = self.font_medium.render(action_text, True, COLORS['blue'])
            self.screen.blit(action_surface, (int(self.screen_width * 0.3), 30))

    def draw_player_info(self):
        """Draw current player information"""
        current_player = self.game.get_current_player()

        info_x = int(self.screen_width * 0.68)
        info_width = int(self.screen_width * 0.3)

        pygame.draw.rect(self.screen, COLORS['white'], (info_x, 50, info_width, 200))
        pygame.draw.rect(self.screen, COLORS['black'], (info_x, 50, info_width, 200), 2)

        y_offset = 60
        player_text = self.display_name(current_player)
        text = self.font_large.render(player_text, True, COLORS['black'])
        self.screen.blit(text, (info_x + 10, y_offset))
        y_offset += 35

        health_text = f"Health: {current_player.health}/{current_player.max_health}"
        text = self.font_medium.render(health_text, True, COLORS['black'])
        self.screen.blit(text, (info_x + 10, y_offset))
        y_offset += 25

        crystal_text = "Crystals:"
        text = self.font_medium.render(crystal_text, True, COLORS['black'])
        self.screen.blit(text, (info_x + 10, y_offset))
        y_offset += 25

        x_offset = info_x + 10
        for color in ['red', 'blue', 'green', 'yellow', 'white']:
            count = current_player.crystals[color]
            if count > 0:
                pygame.draw.circle(self.screen, COLORS[color], (x_offset + 10, y_offset + 10), 8)
                pygame.draw.circle(self.screen, COLORS['black'], (x_offset + 10, y_offset + 10), 8, 1)
                count_text = self.font_small.render(str(count), True, COLORS['black'])
                self.screen.blit(count_text, (x_offset + 25, y_offset + 5))
                x_offset += 50

        y_offset += 35
        actions_text = f"Actions: {self.game.current_actions}/{self.game.max_actions_per_turn}"
        text = self.font_medium.render(actions_text, True, COLORS['black'])
        self.screen.blit(text, (info_x + 10, y_offset))

        y_offset += 20
        limits_text = f"Moves: {self.game.moves_used}/3  Mines: {self.game.mines_used}/2  Spells: {self.game.spells_cast}/1"
        text = self.font_small.render(limits_text, True, COLORS['black'])
        self.screen.blit(text, (info_x + 10, y_offset))

    def draw_spell_cards_fan(self):
        """Draw spell cards in a horizontal row layout with professional styling"""
        current_player = self.game.get_current_player()
        self.spell_card_rects = []

        all_cards = current_player.hand + current_player.cards_laid_down
        if not all_cards:
            return

        # Update mouse position for hover detection
        self.mouse_pos = pygame.mouse.get_pos()

        # Card dimensions and positioning
        base_card_width = int(self.screen_width * 0.10)
        base_card_height = int(self.screen_height * 0.25)
        hover_scale = 1.3
        card_spacing = base_card_width + 15
        
        # Horizontal row positioning
        total_width = len(all_cards) * card_spacing - 15
        start_x = self.screen_width - total_width - 20
        
        # Hand cards in bottom row, laid down cards in upper row
        hand_y = self.screen_height - base_card_height - 10
        board_y = hand_y - int(base_card_height * 0.7)
        
        self.hovered_card_index = None

        # Draw hand cards (bottom row)
        for i, card in enumerate(current_player.hand):
            card_x = start_x + i * card_spacing
            card_y = hand_y
            is_hovered = self._is_card_hovered(card_x, card_y, base_card_width, base_card_height, i)
            
            if is_hovered:
                self.hovered_card_index = i
                
            # Add hover animation
            if is_hovered:
                hover_offset = -10
                card_y += hover_offset
                
            self.draw_spell_card_horizontal(
                card, card_x, card_y, base_card_width, base_card_height,
                True, False, is_hovered, current_player, i
            )

        # Draw laid down cards (upper row)  
        for i, card in enumerate(current_player.cards_laid_down):
            card_x = start_x + i * card_spacing
            card_y = board_y
            card_index = len(current_player.hand) + i
            is_hovered = self._is_card_hovered(card_x, card_y, base_card_width, base_card_height, card_index)
            is_selected = (card == self.selected_spell_card)
            
            if is_hovered:
                self.hovered_card_index = card_index
                
            # Add hover and selection animations
            if is_hovered:
                hover_offset = -8
                card_y += hover_offset
            
            if is_selected:
                # Add pulsing glow for selected cards
                current_time = pygame.time.get_ticks()
                pulse = 0.7 + 0.3 * abs(math.sin(current_time * 0.005))
                glow_size = int(10 * pulse)
                glow_surface = pygame.Surface((base_card_width + glow_size * 2, base_card_height + glow_size * 2), pygame.SRCALPHA)
                pygame.draw.rect(glow_surface, (255, 255, 100, 80), 
                               (0, 0, base_card_width + glow_size * 2, base_card_height + glow_size * 2), 
                               border_radius=10)
                self.screen.blit(glow_surface, (card_x - glow_size, card_y - glow_size))
                
            self.draw_spell_card_horizontal(
                card, card_x, card_y, base_card_width, base_card_height,
                False, is_selected, is_hovered, current_player, card_index
            )

    def _is_card_hovered(self, card_x, card_y, card_width, card_height, card_index):
        """Check if mouse is hovering over a card"""
        mx, my = self.mouse_pos
        return (card_x <= mx <= card_x + card_width and 
                card_y <= my <= card_y + card_height)

    def draw_spell_card_horizontal(self, card, x, y, base_width, base_height,
                                 is_in_hand, is_selected, is_hovered, current_player, card_index):
        """Draw a single spell card in horizontal layout with professional styling"""
        
        # Apply hover scaling
        if is_hovered:
            width = int(base_width * 1.3)
            height = int(base_height * 1.3)
            # Adjust position to keep card centered when scaled
            adjusted_x = x - (width - base_width) // 2
            adjusted_y = y - (height - base_height) // 2
        else:
            width = base_width
            height = base_height
            adjusted_x = x
            adjusted_y = y

        # Draw shadow first (professional effect)
        shadow_offset = 3
        shadow_surface = pygame.Surface((width + shadow_offset * 2, height + shadow_offset * 2), pygame.SRCALPHA)
        shadow_color = (0, 0, 0, 60)  # Semi-transparent black
        pygame.draw.rect(shadow_surface, shadow_color, 
                        (shadow_offset, shadow_offset, width, height), border_radius=8)
        self.screen.blit(shadow_surface, (adjusted_x - shadow_offset, adjusted_y - shadow_offset))

        # Create card surface
        card_surface = pygame.Surface((width, height), pygame.SRCALPHA)

        # Card background colors
        if is_selected:
            card_color = COLORS['gold']
        elif is_hovered:
            card_color = (255, 255, 240)  # Light cream color for hover
        elif is_in_hand:
            card_color = COLORS['white']
        else:
            card_color = COLORS['light_blue']

        # Draw card background with rounded corners
        pygame.draw.rect(card_surface, card_color, (0, 0, width, height), border_radius=8)

        # Card border
        border_color = COLORS['gold'] if is_selected else COLORS['black']
        border_width = 4 if is_selected else 2
        pygame.draw.rect(card_surface, border_color, (0, 0, width, height), border_width, border_radius=8)

        # Draw damage number at top center
        damage_font_size = int(height * 0.30)
        damage_font = pygame.font.Font(None, damage_font_size)
        damage_text = damage_font.render(str(card.get_damage()), True, COLORS['black'])
        damage_rect = damage_text.get_rect(center=(width // 2, damage_font_size // 2 + 10))
        card_surface.blit(damage_text, damage_rect)

        # Draw crystal costs (always visible, no rotation)
        y_offset = height // 3
        crystal_size = max(6, int(width * 0.08))
        font_size = max(20, int(width * 0.30))
        cost_font = pygame.font.Font(None, font_size)

        for color, cost in card.cost.items():
            if cost > 0:
                crystal_x = width // 4
                
                # Draw crystal circle
                pygame.draw.circle(card_surface, COLORS.get(color, COLORS['wild']), 
                                 (crystal_x, y_offset), crystal_size)
                pygame.draw.circle(card_surface, COLORS['black'], 
                                 (crystal_x, y_offset), crystal_size, 2)

                # Draw crystal cost/progress text
                if not is_in_hand:
                    placed = card.crystals_used.get(color, 0)
                    progress_text = f"{placed}/{cost}"
                    text_color = COLORS['green'] if placed >= cost else COLORS['red']
                else:
                    progress_text = str(cost)
                    text_color = COLORS['black']

                cost_text = cost_font.render(progress_text, True, text_color)
                card_surface.blit(cost_text, (crystal_x + crystal_size + 5, y_offset - font_size // 2))
                y_offset += crystal_size * 2 + 8

        # Draw charging progress bar for laid down cards
        if not is_in_hand:
            progress = card.get_charging_progress()
            bar_y = height - 25
            bar_width = width - 10
            bar_height = 8
            
            # Background bar
            pygame.draw.rect(card_surface, COLORS['grey'], (5, bar_y, bar_width, bar_height), border_radius=4)
            
            # Progress bar
            progress_width = int(bar_width * progress)
            bar_color = COLORS['green'] if progress >= 1.0 else COLORS['yellow']
            if progress_width > 0:
                pygame.draw.rect(card_surface, bar_color, (5, bar_y, progress_width, bar_height), border_radius=4)
            
            # Progress percentage
            progress_text = f"{int(progress * 100)}%"
            progress_surface = self.font_small.render(progress_text, True, COLORS['black'])
            card_surface.blit(progress_surface, (5, bar_y - 18))

        # Store click detection rectangle (use original position for consistent clicking)
        click_rect = pygame.Rect(x, y, base_width, base_height)
        self.spell_card_rects.append(click_rect)

        # Blit the card to screen
        self.screen.blit(card_surface, (adjusted_x, adjusted_y))

        # Draw crystal placement UI if this card is selected
        if self.selected_spell_card and card == self.selected_spell_card:
            self.draw_crystal_placement_ui(current_player)

    def draw_crystal_placement_ui(self, current_player):
        """Draw the crystal placement interface"""
        crystal_area_x = int(self.screen_width * 0.75)
        crystal_area_y = int(self.screen_height * 0.45)

        label_font = pygame.font.Font(None, 40)
        crystal_label = label_font.render("Place Crystals:", True, COLORS['black'])
        self.screen.blit(crystal_label, (crystal_area_x, crystal_area_y - 25))

        colors = ['red', 'blue', 'green', 'yellow', 'white']
        for i, color in enumerate(colors):
            x = crystal_area_x + i * 35
            y = crystal_area_y
            pygame.draw.circle(self.screen, COLORS[color], (x + 15, y + 15), 15)
            pygame.draw.circle(self.screen, COLORS['black'], (x + 15, y + 15), 15, 2)

            required = self.selected_spell_card.cost.get(color, 0)
            placed = self.selected_spell_card.crystals_used.get(color, 0)
            if required > 0:
                progress_text = f"{placed}/{required}"
                text_color = COLORS['green'] if placed >= required else COLORS['black']
                progress_surface = self.font_small.render(progress_text, True, text_color)
                self.screen.blit(progress_surface, (x, y + 35))

    def draw_opponent_cards_area(self):
        """Draw opponent players' laid down cards in a compact format on the left side"""
        current_player = self.game.get_current_player()
        
        # Get all opponents (players other than current player)
        opponents = [player for player in self.game.players if player != current_player]
        
        if not opponents:
            return
            
        # Define the opponent area dimensions
        area_width = int(self.screen_width * 0.25)  # 25% of screen width
        area_x = 10  # Left margin
        area_y = 70   # Start below turn indicator
        max_area_height = int(self.screen_height * 0.7)  # Max 70% of screen height
        
        # Calculate space per opponent
        opponent_height = min(max_area_height // len(opponents), 200)
        
        for i, opponent in enumerate(opponents):
            opponent_y = area_y + i * (opponent_height + 10)
            
            # Draw opponent section background
            section_rect = pygame.Rect(area_x, opponent_y, area_width, opponent_height)
            pygame.draw.rect(self.screen, COLORS['white'], section_rect)
            pygame.draw.rect(self.screen, COLORS['black'], section_rect, 2)
            
            # Draw opponent name/color header
            header_height = 30
            header_rect = pygame.Rect(area_x, opponent_y, area_width, header_height)
            opponent_color = COLORS.get(opponent.color, COLORS['black'])
            pygame.draw.rect(self.screen, opponent_color, header_rect)
            pygame.draw.rect(self.screen, COLORS['black'], header_rect, 2)
            
            # Opponent name text
            opponent_name = self.display_name(opponent)
            name_font = pygame.font.Font(None, 36)
            name_text = name_font.render(opponent_name, True, COLORS['white'])
            name_rect = name_text.get_rect(center=(area_x + area_width // 2, opponent_y + header_height // 2))
            self.screen.blit(name_text, name_rect)
            
            # Draw opponent's laid down cards
            if opponent.cards_laid_down:
                cards_area_y = opponent_y + header_height + 5
                cards_area_height = opponent_height - header_height - 10
                
                self.draw_opponent_cards_compact(opponent, area_x + 5, cards_area_y, 
                                                area_width - 10, cards_area_height)
            else:
                # Show "No cards played" message
                no_cards_text = self.font_small.render("No cards played", True, COLORS['dark_grey'])
                text_rect = no_cards_text.get_rect(center=(area_x + area_width // 2, 
                                                          opponent_y + header_height + 20))
                self.screen.blit(no_cards_text, text_rect)

    def draw_opponent_cards_compact(self, opponent, x, y, width, height):
        """Draw opponent's cards in a compact grid layout"""
        cards = opponent.cards_laid_down
        if not cards:
            return
            
        # Calculate card dimensions (smaller than main player cards)
        cards_per_row = min(3, len(cards))  # Max 3 cards per row
        rows_needed = (len(cards) + cards_per_row - 1) // cards_per_row
        
        card_width = min((width - 10) // cards_per_row - 5, 80)  # Compact size
        card_height = min(height // rows_needed - 5, 120)  # Compact size
        
        for i, card in enumerate(cards):
            row = i // cards_per_row
            col = i % cards_per_row
            
            # Calculate card position
            cards_in_row = min(cards_per_row, len(cards) - row * cards_per_row)
            row_width = cards_in_row * (card_width + 5) - 5
            start_x = x + (width - row_width) // 2  # Center the row
            
            card_x = start_x + col * (card_width + 5)
            card_y = y + row * (card_height + 5)
            
            self.draw_compact_spell_card(card, card_x, card_y, card_width, card_height)

    def draw_compact_spell_card(self, card, x, y, width, height):
        """Draw a single spell card in compact format"""
        # Create card surface
        card_surface = pygame.Surface((width, height))
        
        # Determine card color based on charging status
        progress = card.get_charging_progress()
        if progress >= 1.0:
            card_color = COLORS['light_blue']  # Fully charged
        else:
            card_color = COLORS['white']  # Still charging
            
        card_surface.fill(card_color)
        
        # Draw border
        border_color = COLORS['green'] if progress >= 1.0 else COLORS['black']
        border_width = 2 if progress >= 1.0 else 1
        pygame.draw.rect(card_surface, border_color, (0, 0, width, height), border_width)
        
        # Draw damage value at top
        damage_font = pygame.font.Font(None, max(32, int(height * 0.30)))
        damage_text = damage_font.render(str(card.get_damage()), True, COLORS['black'])
        damage_rect = damage_text.get_rect(center=(width // 2, height // 8))
        card_surface.blit(damage_text, damage_rect)
        
        # Draw crystal costs
        y_offset = height // 4
        crystal_size = max(4, int(width * 0.08))
        cost_font_size = max(20, int(width * 0.30))
        cost_font = pygame.font.Font(None, cost_font_size)
        
        for color, cost in card.cost.items():
            if cost > 0:
                crystal_x = width // 6
                
                # Draw crystal circle
                pygame.draw.circle(card_surface, COLORS.get(color, COLORS['wild']), 
                                 (crystal_x, y_offset), crystal_size)
                pygame.draw.circle(card_surface, COLORS['black'], 
                                 (crystal_x, y_offset), crystal_size, 1)
                
                # Show progress (placed/required)
                placed = card.crystals_used.get(color, 0)
                progress_text = f"{placed}/{cost}"
                text_color = COLORS['green'] if placed >= cost else COLORS['red']
                
                cost_text = cost_font.render(progress_text, True, text_color)
                card_surface.blit(cost_text, (crystal_x + crystal_size + 2, 
                                            y_offset - cost_font_size // 2))
                y_offset += crystal_size * 2 + 2
        
        # Draw charging progress bar at bottom
        bar_height = max(3, int(height * 0.05))
        bar_y = height - bar_height - 2
        bar_width = width - 4
        
        # Background bar
        pygame.draw.rect(card_surface, COLORS['grey'], (2, bar_y, bar_width, bar_height))
        
        # Progress bar
        progress_width = int(bar_width * progress)
        bar_color = COLORS['green'] if progress >= 1.0 else COLORS['yellow']
        pygame.draw.rect(card_surface, bar_color, (2, bar_y, progress_width, bar_height))
        
        # Progress percentage text (very small)
        if height > 60:  # Only show percentage if card is tall enough
            progress_text = f"{int(progress * 100)}%"
            progress_font = pygame.font.Font(None, max(16, int(height * 0.16)))
            progress_surface = progress_font.render(progress_text, True, COLORS['black'])
            card_surface.blit(progress_surface, (2, bar_y - 12))
        
        # Blit the card to screen
        self.screen.blit(card_surface, (x, y))

    def draw_game_status_panel(self):
        """Draw the ticker tape and all player statuses at the bottom."""
        panel_height = int(self.screen_height * 0.18)
        panel_y = self.screen_height - panel_height - 10
        panel_width = int(self.screen_width * 0.65)

        panel_rect = pygame.Rect(10, panel_y, panel_width, panel_height)
        pygame.draw.rect(self.screen, COLORS['white'], panel_rect)
        pygame.draw.rect(self.screen, COLORS['black'], panel_rect, 2)

        # Ticker/log
        log_width = int(panel_width * 0.6)
        log_area_rect = pygame.Rect(panel_rect.x + 10, panel_rect.y + 10, log_width, panel_height - 20)

        log_title = self.font_medium.render("Action Log", True, COLORS['black'])
        self.screen.blit(log_title, (log_area_rect.x, log_area_rect.y))

        if hasattr(self.game, 'action_log'):
            log_entries = list(self.game.action_log)[-5:]
            y_offset = log_area_rect.bottom - 20
            for entry in reversed(log_entries):
                log_text = self.font_small.render(entry, True, COLORS['dark_grey'])
                self.screen.blit(log_text, (log_area_rect.x + 5, y_offset))
                y_offset -= 18
                if y_offset < log_area_rect.y + 20:
                    break

        # All players status
        status_width = int(panel_width * 0.35)
        status_area_rect = pygame.Rect(panel_rect.x + log_width + 20, panel_rect.y + 10, status_width, panel_height - 20)

        status_title = self.font_medium.render("All Wizards", True, COLORS['black'])
        self.screen.blit(status_title, (status_area_rect.x, status_area_rect.y))

        y_offset = status_area_rect.y + 25
        for player in self.game.players:
            player_color_rgb = COLORS.get(player.color, COLORS['black'])
            status_text = f"{self.display_name(player)}: {player.health}/{player.max_health} HP"
            text_surface = self.font_small.render(status_text, True, player_color_rgb)
            self.screen.blit(text_surface, (status_area_rect.x, y_offset))

            x_offset = status_area_rect.x + 220
            for crystal_color_str in ['red', 'blue', 'green', 'yellow', 'white']:
                count = player.crystals.get(crystal_color_str, 0)
                if count > 0:
                    crystal_color = COLORS[crystal_color_str]
                    pygame.draw.circle(self.screen, crystal_color, (x_offset, y_offset + 8), 6)
                    pygame.draw.circle(self.screen, COLORS['black'], (x_offset, y_offset + 8), 6, 1)
                    count_surface = self.font_small.render(str(count), True, COLORS['black'])
                    self.screen.blit(count_surface, (x_offset + 10, y_offset + 3))
                    x_offset += 25

            y_offset += 20

    def draw_game_over(self):
        """Draw game over screen"""
        overlay = pygame.Surface((self.screen_width, self.screen_height))
        overlay.fill(COLORS['black'])
        overlay.set_alpha(128)
        self.screen.blit(overlay, (0, 0))

        game_over_font = pygame.font.Font(None, int(self.screen_height * 0.16))
        game_over_text = game_over_font.render("GAME OVER", True, COLORS['white'])
        game_over_rect = game_over_text.get_rect(center=(self.screen_width // 2, self.screen_height // 2 - 100))
        self.screen.blit(game_over_text, game_over_rect)

        winner_font = pygame.font.Font(None, int(self.screen_height * 0.10))
        winner = self.game.get_winner()
        if winner:
            label = f"{self.display_name(winner)} Wins!"
            winner_text = winner_font.render(label, True, COLORS['gold'])
            winner_rect = winner_text.get_rect(center=(self.screen_width // 2, self.screen_height // 2))
            self.screen.blit(winner_text, winner_rect)

    def _process_ai_turn_with_animations(self, current_player, current_time):
        """Process AI turn with proper animation delays between actions"""
        # Initial thinking delay
        if not self.ai_turn_executed and (current_time - self.ai_turn_start_time) < self.ai_thinking_delay:
            return
            
        # Generate actions queue if not done yet
        if not self.ai_turn_executed and not self.ai_actions_queue:
            self.ai_actions_queue = self._generate_ai_actions_queue(current_player)
            self.ai_turn_executed = True
            self.ai_last_action_time = current_time
            self.ai_current_action_index = 0
            
        # Process actions from queue with delays
        if self.ai_actions_queue and self.ai_current_action_index < len(self.ai_actions_queue):
            # Check if enough time has passed since last action
            if (current_time - self.ai_last_action_time) >= self.ai_action_delay:
                action = self.ai_actions_queue[self.ai_current_action_index]
                success = self._execute_ai_action_with_animation(action, current_player)
                
                if success:
                    self.ai_current_action_index += 1
                    self.ai_last_action_time = current_time
                else:
                    # Skip failed action
                    self.ai_current_action_index += 1
                    
        # Check if turn should end
        elif (self.game.current_actions >= self.game.max_actions_per_turn or 
              self.ai_current_action_index >= len(self.ai_actions_queue)):
            self.game.end_turn()
            # Update button visibility for the new current player
            new_current_player = self.game.get_current_player()
            self.action_panel.set_ai_turn_state(isinstance(new_current_player, AIWizard))
            # Reset for next turn
            self.ai_turn_start_time = 0
            self.ai_turn_executed = False
            self.ai_actions_queue = []
            self.ai_current_action_index = 0
            
    def _generate_ai_actions_queue(self, ai_player):
        #"""Generate a queue of actions for the AI player to execute with animations - FIXED VERSION"""
        actions_queue = []
        
        # Use the AI controller to determine actions
        if hasattr(ai_player, 'ai_controller') and ai_player.ai_controller:
            ai_controller = ai_player.ai_controller
            
            # FIXED: Create a simulation context without modifying actual game state
            simulation_state = {
                'original_actions': self.game.current_actions,
                'simulated_location': ai_player.location,  # Track simulated position separately
                'original_location': ai_player.location
            }
            
            max_actions = min(self.game.max_actions_per_turn - simulation_state['original_actions'], 5)
            
            for action_index in range(max_actions):
                if simulation_state['original_actions'] + action_index >= self.game.max_actions_per_turn:
                    break
                
                # FIXED: Get possible actions using simulated state instead of modifying real state
                possible_actions = self._get_ai_possible_actions_simulated(ai_controller, ai_player, simulation_state)
                if not possible_actions:
                    break
                
                # Select best action using simulated context
                best_action = ai_controller._select_best_action(possible_actions, self.game)
                if not best_action:
                    break
                
                actions_queue.append(best_action)
                
                # FIXED: Update simulation state without touching real wizard location
                if best_action['type'] == 'move':
                    simulation_state['simulated_location'] = best_action['target']
                    # Store the simulated position for reference, but don't modify wizard.location
                    best_action['simulated_from'] = simulation_state['simulated_location']
            
            # NO RESTORATION NEEDED - we never modified the real state!
        
        return actions_queue
    
    def _get_ai_possible_actions_simulated(self, ai_controller, ai_player, simulation_state):
        """Get possible AI actions using simulated state without modifying real game state"""
        # Temporarily create a simulation context
        original_location = ai_player.location
        
        try:
            # SAFE: Only modify location for the duration of this method call
            ai_player.location = simulation_state['simulated_location']
            
            # Get actions with the simulated position
            possible_actions = ai_controller._get_possible_actions(self.game)
            
            return possible_actions
            
        finally:
            # CRITICAL: Always restore the original location immediately
            ai_player.location = original_location
        
    def _execute_ai_action_with_animation(self, action, ai_player):
        """Execute a single AI action with proper animation - UPDATED VERSION"""
        if not action:
            return False
        
        action_type = action['type']
        success = False
        
        try:
            if action_type == 'cast_spell':
                # Trigger spell animation first
                self._trigger_ai_spell_animation(action, ai_player)
                success = self.game.cast_spell(ai_player, action['spell_card'], self)
            
            elif action_type in ['mine_white_hex', 'mine_from_mine']:
                # FIXED: Handle both hex and mine mining with proper animation
                mine_color = action.get('mine_color', 'white')
                self._trigger_ai_mining_animation(action, ai_player, mine_color)
                
                if action_type == 'mine_white_hex':
                    success = self.game.mine_white_crystal(ai_player, action['position'])
                else:  # mine_from_mine
                    roll = random.randint(1, 6) if action['position'] != 'center' else random.choice([3, 2, 2, 1, 1, 1])
                    success = self.game.resolve_mine_with_roll(ai_player, action['position'], roll)
            
            elif action_type == 'lay_card':
                success = ai_player.lay_down_spell_card(action['card_index'])
            
            elif action_type == 'charge_card':
                success = action['card'].add_crystals(action['color'], 1, ai_player)
            
            elif action_type == 'move':
                # FIXED: Ensure movement animation uses correct positions
                old_location = ai_player.location  # Use REAL current location
                target_location = action['target']
                
                # Trigger movement animation BEFORE actually moving
                if old_location in self.position_coords and target_location in self.position_coords:
                    old_x, old_y = self.position_coords[old_location]
                    new_x, new_y = self.position_coords[target_location]
                    wizard_id = f"{ai_player.color}_{id(ai_player)}"
                    
                    animation_manager.start_wizard_movement(wizard_id, (old_x, old_y), (new_x, new_y), 0.5)
                
                # NOW execute the actual move
                success = self.game.move_player(ai_player, target_location)
            
            return success
            
        except Exception as e:
            print(f"AI action execution failed for {action_type}: {e}")
            return False
            
    def _trigger_ai_spell_animation(self, action, ai_player):
        """Trigger spell casting animation and effects for AI"""
        try:
            # Get wizard position
            if ai_player.location in self.position_coords:
                caster_x, caster_y = self.position_coords[ai_player.location]
                
                # Create spell cast effect at caster position
                primary_color = self.get_wizard_color(ai_player.color)
                if AI_ENABLE_PARTICLE_EFFECTS:
                    particle_count = int(30 * AI_PARTICLE_DENSITY)
                    particle_system.create_spell_cast_effect(caster_x, caster_y, primary_color, particle_count)
                
                # Create spell trail effects to adjacent enemies
                adjacent_positions = self.game.board.get_adjacent_positions(ai_player.location)
                for pos in adjacent_positions:
                    if pos in self.position_coords:
                        target_x, target_y = self.position_coords[pos]
                        wizards_at_pos = self.game.board.get_wizard_at_position(pos)
                        if wizards_at_pos and any(w != ai_player for w in wizards_at_pos):
                            if AI_ENABLE_PARTICLE_EFFECTS:
                                particle_system.create_spell_trail_effect(
                                    caster_x, caster_y, target_x, target_y, primary_color
                                )
                
                # Play spell cast sound
                if AI_ENABLE_SOUND_EFFECTS:
                    self.sound_manager.play_sound('spell_cast', 0.8)
                    
        except Exception as e:
            print(f"Failed to trigger AI spell animation: {e}")
            
    def _trigger_ai_mining_animation(self, action, ai_player, crystal_type):
        """Trigger mining animation and effects for AI"""
        try:
            position = action['position']
            if position in self.position_coords:
                mine_x, mine_y = self.position_coords[position]
                
                # Determine crystal color for effect
                if crystal_type == 'white':
                    crystal_color = 'white'
                elif crystal_type == 'healing':
                    crystal_color = 'healing'
                else:
                    # For colored crystals, use the mine's color
                    crystal_color = self.game.board.get_mine_color(position) or 'white'
                
                # Create mining effect
                if AI_ENABLE_PARTICLE_EFFECTS:
                    particle_system.create_mining_effect(mine_x, mine_y, crystal_color)
                    
                    # Create crystal pickup effect
                    particle_system.create_crystal_pickup_effect(mine_x, mine_y, crystal_color)
                
        except Exception as e:
            print(f"Failed to trigger AI mining animation: {e}")
            
    def _trigger_ai_movement_animation(self, action, ai_player):
        """Trigger movement animation for AI"""
        try:
            old_location = ai_player.location
            new_location = action['target']
            
            if old_location in self.position_coords and new_location in self.position_coords:
                old_x, old_y = self.position_coords[old_location]
                new_x, new_y = self.position_coords[new_location]
                wizard_id = f"{ai_player.color}_{id(ai_player)}"
                
                # Start movement animation with configurable duration
                if AI_ENABLE_MOVEMENT_ANIMATION:
                    duration_seconds = AI_MOVEMENT_DURATION / 1000.0  # Convert ms to seconds
                    animation_manager.start_wizard_movement(wizard_id, (old_x, old_y), (new_x, new_y), duration_seconds)
                
                # Play movement sound
                if AI_ENABLE_SOUND_EFFECTS:
                    self.sound_manager.play_move()
                    
        except Exception as e:
            print(f"Failed to trigger AI movement animation: {e}")

def main():
    """Simple test to run the GUI with a sample game"""
    pygame.init()
    try:
        game = CrystalWizardsGame(num_players=2, num_ai=1)
        gui = GameGUI(game)
        gui.run()
    except Exception as e:
        print(f"Error running GUI test: {e}")
        import traceback
        traceback.print_exc()
    finally:
        pygame.quit()

if __name__ == "__main__":
    main()