"""
Crystal Wizards - Modified GUI with Help Menu Integration
This file shows the specific changes needed to integrate the help menu system.
"""

# At the top of cw_gui.py, add this import:
from help_menu_system import PauseMenuDialog

# In the GameGUI.__init__ method, replace the quit_dialog initialization:
# REPLACE THIS LINE:
# self.quit_dialog = QuitConfirmDialog(self.screen, self.font_large)

# WITH THIS LINE:
# self.pause_menu = PauseMenuDialog(self.screen, self.font_medium, self.font_large)

# In the run() method, replace the quit dialog calls in TWO places:

# LOCATION 1: pygame.QUIT event (around line 753)
# REPLACE THESE LINES:
# if event.type == pygame.QUIT:
#     if self.quit_dialog.run_modal():
#         running = False
#         break

# WITH THESE LINES:
# if event.type == pygame.QUIT:
#     result = self.pause_menu.run_modal()
#     if result == 'quit':
#         running = False
#         break
#     elif result == 'resume':
#         continue

# LOCATION 2: pygame.K_ESCAPE event (around line 776)
# REPLACE THESE LINES:
# if event.key == pygame.K_ESCAPE:
#     if self.quit_dialog.run_modal():
#         running = False
#         break

# WITH THESE LINES:
# if event.key == pygame.K_ESCAPE:
#     result = self.pause_menu.run_modal()
#     if result == 'quit':
#         running = False
#         break
#     elif result == 'resume':
#         continue

"""
COMPLETE MODIFIED SECTIONS:

Here are the exact code sections that need to be changed in cw_gui.py:

1. ADD IMPORT (after line with other imports):
from help_menu_system import PauseMenuDialog

2. MODIFY __init__ method (around line 700):
# Replace:
self.quit_dialog = QuitConfirmDialog(self.screen, self.font_large)
# With:
self.pause_menu = PauseMenuDialog(self.screen, self.font_medium, self.font_large)

3. MODIFY run() method - QUIT event (around line 753):
# Replace:
if event.type == pygame.QUIT:
    if self.quit_dialog.run_modal():
        running = False
        break
# With:
if event.type == pygame.QUIT:
    result = self.pause_menu.run_modal()
    if result == 'quit':
        running = False
        break

4. MODIFY run() method - ESCAPE key (around line 776):
# Replace:
if event.key == pygame.K_ESCAPE:
    if self.quit_dialog.run_modal():
        running = False
        break
# With:
if event.key == pygame.K_ESCAPE:
    result = self.pause_menu.run_modal()
    if result == 'quit':
        running = False
        break

That's it! These 4 changes will integrate the help menu system into your game.
"""
